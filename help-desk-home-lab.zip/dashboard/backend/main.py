"""Help desk lab dashboard - FastAPI back end.

Serves the built React app and a small read-only API:

  GET  /api/endpoints              aggregated health of pc-01..04 (proxied from :9000)
  GET  /api/tickets                osTicket queue, read straight from the DB (read-only)
  GET  /api/metrics                resolved today / MTTR / SLA breaches / FCR
  GET  /api/scenarios              scenario catalogue + which are active
  POST /api/scenarios/{name}/run   inject a fault + file its ticket
  POST /api/scenarios/{name}/verify
  POST /api/scenarios/{name}/reset
  POST /api/lab/reset              reset every scenario + clear demo tickets
  WS   /api/terminal               interactive shell in this container (docker CLI + compose)
"""
from __future__ import annotations

import asyncio
import fcntl
import json
import os
import pty
import re
import signal
import struct
import subprocess
import termios
import time
from pathlib import Path

import httpx
import pymysql
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

LAB_DIR = Path(os.environ.get("LAB_DIR", "/lab"))
STATIC_DIR = Path(os.environ.get("STATIC_DIR", "/app/static"))
ENGINE = LAB_DIR / "scripts" / "_engine.py"

DB = dict(
    host=os.environ.get("DB_HOST", "172.28.0.20"),
    user=os.environ.get("DB_USER", "dashboard"),
    password=os.environ.get("DB_PASSWORD", "dashRO!1"),
    database=os.environ.get("DB_NAME", "osticket"),
    cursorclass=pymysql.cursors.DictCursor,
    connect_timeout=4,
    read_timeout=6,
)

ENDPOINTS = [
    {"pc": "PC-01", "url": "http://172.28.0.101:9000/health"},
    {"pc": "PC-02", "url": "http://172.28.0.102:9000/health"},
    {"pc": "PC-03", "url": "http://172.28.0.103:9000/health"},
    {"pc": "PC-04", "url": "http://172.28.0.104:9000/health"},
]

PRIORITY_META = {
    "Emergency": {"rank": 4, "color": "#dc2626"},
    "High":      {"rank": 3, "color": "#ea580c"},
    "Normal":    {"rank": 2, "color": "#0891b2"},
    "Low":       {"rank": 1, "color": "#64748b"},
}

app = FastAPI(title="Help Desk Lab Dashboard")


# --------------------------------------------------------------------- helpers
def query(sql: str, args=None) -> list[dict]:
    conn = pymysql.connect(**DB)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, args or ())
            return cur.fetchall()
    finally:
        conn.close()


def engine(*args: str, timeout: int = 90) -> dict:
    if not ENGINE.exists():
        raise HTTPException(503, "scenario engine not mounted")
    p = subprocess.run(
        ["python3", str(ENGINE), *args],
        capture_output=True, text=True, timeout=timeout,
    )
    clean = re.sub(r"\x1b\[[0-9;]*m", "", p.stdout + p.stderr)
    return {"ok": p.returncode == 0, "code": p.returncode, "output": clean.strip()}


# -------------------------------------------------------------------- endpoints
@app.get("/api/endpoints")
async def endpoints():
    async def one(ep):
        try:
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.get(ep["url"])
                data = r.json()
                data["reachable"] = True
                return data
        except Exception as e:  # noqa: BLE001
            return {"pc": ep["pc"], "reachable": False, "status": "unknown",
                    "error": str(e), "status_reasons": ["agent unreachable"]}

    results = await asyncio.gather(*(one(ep) for ep in ENDPOINTS))
    return {"generated_at": time.time(), "endpoints": list(results)}


# ---------------------------------------------------------------------- tickets
TICKET_SQL = """
SELECT
  t.ticket_id, t.number, t.created, t.closed, t.duedate, t.reopened,
  st.name  AS status, st.state AS state,
  d.name   AS dept,
  ht.topic AS topic,
  sla.name AS sla_name, sla.grace_period AS grace_hours,
  subj.value AS subject,
  prio.value AS priority,
  u.name   AS requester
FROM ost_ticket t
LEFT JOIN ost_ticket_status st ON st.id = t.status_id
LEFT JOIN ost_department     d ON d.id  = t.dept_id
LEFT JOIN ost_help_topic    ht ON ht.topic_id = t.topic_id
LEFT JOIN ost_sla          sla ON sla.id = t.sla_id
LEFT JOIN ost_form_entry    fe ON fe.object_id = t.ticket_id AND fe.object_type = 'T'
LEFT JOIN ost_form_entry_values subj ON subj.entry_id = fe.id
     AND subj.field_id IN (SELECT id FROM ost_form_field WHERE name = 'subject')
LEFT JOIN ost_form_entry_values prio ON prio.entry_id = fe.id
     AND prio.field_id IN (SELECT id FROM ost_form_field WHERE name = 'priority')
LEFT JOIN ost_user u ON u.id = t.user_id
WHERE st.state IN ('open', 'closed')
ORDER BY t.created DESC
LIMIT 200
"""


@app.get("/api/tickets")
def tickets():
    now = time.time()
    rows = query(TICKET_SQL)
    out = []
    for r in rows:
        created = r["created"].timestamp() if r["created"] else now
        due = r["duedate"].timestamp() if r["duedate"] else (
            created + (r["grace_hours"] or 24) * 3600)
        closed = r["closed"].timestamp() if r["closed"] else None
        is_open = r["state"] == "open"
        ref = closed or now
        secs_left = due - ref
        pm = PRIORITY_META.get(r["priority"] or "Normal", PRIORITY_META["Normal"])
        out.append({
            "number": r["number"],
            "subject": r["subject"] or "(no subject)",
            "requester": r["requester"] or "unknown",
            "dept": r["dept"],
            "topic": r["topic"],
            "priority": r["priority"] or "Normal",
            "priority_color": pm["color"],
            "priority_rank": pm["rank"],
            "status": r["status"],
            "state": r["state"],
            "is_open": is_open,
            "reopened": bool(r["reopened"]),
            "created": created,
            "closed": closed,
            "due": due,
            "sla_name": r["sla_name"] or "-",
            "seconds_to_breach": round(secs_left),
            "breached": secs_left < 0,
        })
    out.sort(key=lambda t: (not t["is_open"], t["seconds_to_breach"]))
    return {"generated_at": now, "tickets": out}


# ---------------------------------------------------------------------- metrics
@app.get("/api/metrics")
def metrics():
    now = time.time()
    # open tickets + SLA breaches come from the live osTicket queue
    agg = query("""
        SELECT
          SUM(st.state='open')                                                AS open_count,
          SUM(st.state='open' AND t.duedate IS NOT NULL AND t.duedate < NOW()) AS sla_breaches_open
        FROM ost_ticket t
        LEFT JOIN ost_ticket_status st ON st.id = t.status_id
        WHERE st.state IN ('open','closed')
    """)[0]

    # solved-count + fix-time come from the lab's own solved log
    solved = _ENGINE_MOD.solved_entries() if _ENGINE_MOD else []
    today = time.strftime("%Y-%m-%d")
    todays = [s for s in solved if time.strftime("%Y-%m-%d", time.localtime(s.get("solved_at", 0))) == today]
    durations = [s["solved_at"] - s["injected_at"]
                 for s in todays
                 if s.get("injected_at") and s.get("solved_at")]
    mttr = int(sum(durations) / len(durations)) if durations else None

    return {
        "generated_at": now,
        "open_count": int(agg["open_count"] or 0),
        "solved_total": len(solved),
        "solved_today": len(todays),
        "mttr_seconds": mttr,
        "sla_breaches": int(agg["sla_breaches_open"] or 0),
    }


@app.get("/api/solved/latest")
def solved_latest():
    """The most recent PASS — so the dashboard can pop the 'Solved' modal even
    when the check was run from the terminal (scripts/verify.sh)."""
    entries = _ENGINE_MOD.solved_entries() if _ENGINE_MOD else []
    if not entries:
        return {"at": 0, "count": 0}
    e = entries[-1]
    sc = next((s for s in _parse_scenarios() if s["name"] == e["name"]), {})
    secs = None
    if e.get("injected_at") and e.get("solved_at"):
        secs = e["solved_at"] - e["injected_at"]
    today = time.strftime("%Y-%m-%d")
    solved_today = len([x for x in entries
                        if time.strftime("%Y-%m-%d", time.localtime(x.get("solved_at", 0))) == today])
    return {
        "at": e["solved_at"],
        "count": len(entries),
        "name": e["name"],
        "subject": sc.get("ticket_subject") or e["name"],
        "seconds": secs,
        "solved_today": solved_today,
    }


# -------------------------------------------------------------------- scenarios
def _load_engine_module():
    import importlib.util
    spec = importlib.util.spec_from_file_location("labengine", ENGINE)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_ENGINE_MOD = _load_engine_module() if ENGINE.exists() else None


def _parse_scenarios() -> list[dict]:
    import json
    scen_dir = LAB_DIR / "scenarios"
    state_dir = LAB_DIR / ".labstate"
    active = {}
    if state_dir.exists():
        for f in state_dir.glob("*.json"):
            try:
                active[f.stem] = json.loads(f.read_text())
            except Exception:  # noqa: BLE001
                active[f.stem] = {}
    if not _ENGINE_MOD or not scen_dir.exists():
        return []
    items = []
    for path in sorted(scen_dir.glob("*.yaml")):
        d = _ENGINE_MOD.load_yaml(path.read_text())
        name = path.stem
        items.append({
            "name": name,
            "title": d.get("title", name),
            "target": d.get("target", "dc"),
            "user": d.get("user"),
            "user_display": d.get("user_display"),
            "department": d.get("department"),
            "priority": d.get("priority"),
            "fix": (d.get("fix") or "").strip(),
            "ticket_subject": (d.get("ticket") or {}).get("subject"),
            "active": name in active,
            "active_since": active.get(name, {}).get("injected_at"),
            "ticket_number": active.get(name, {}).get("ticket_number"),
        })
    return items


@app.get("/api/scenarios")
def scenarios():
    return {"scenarios": _parse_scenarios()}


@app.get("/api/scenarios/{name}/solution")
def scenario_solution(name: str):
    f = LAB_DIR / "scenarios" / f"{name}.solution.md"
    if not f.exists():
        raise HTTPException(404, "no solution for that scenario")
    return {"name": name, "markdown": f.read_text()}


async def _file_ticket_later(name: str, delay: float):
    """The user 'notices' the outage a bit after it happens, then files a ticket."""
    await asyncio.sleep(delay)
    await asyncio.to_thread(engine, "file-ticket", name)


@app.post("/api/scenarios/{name}/run")
async def scenario_run(name: str, only_when_clear: bool = False):
    import random
    scen = _parse_scenarios()
    # a ticket already open and unsolved? (used by auto-mode: one at a time)
    unsolved = [s for s in scen if s["active"]]
    if only_when_clear and unsolved:
        return {"ok": True, "phase": "waiting", "scenario": None,
                "output": "a ticket is still open — finish it first"}

    if name == "random":
        inactive = [s["name"] for s in scen if not s["active"]]
        if not inactive:
            raise HTTPException(409, "every scenario is already active — clear some first")
        name = random.choice(inactive)

    # 1. break the workstation now (no ticket yet)
    res = engine("run", name, "--no-ticket", timeout=60)
    # 2. the ticket lands a little later, so the outage shows up first
    asyncio.create_task(_file_ticket_later(name, random.uniform(9, 16)))
    res["scenario"] = name
    res["phase"] = "fault injected — ticket incoming"
    return res


@app.post("/api/scenarios/{name}/verify")
def scenario_verify(name: str):
    res = engine("verify", name, timeout=45)
    res["verdict"] = "PASS" if res["ok"] else "FAIL"
    return res


@app.post("/api/scenarios/{name}/reset")
def scenario_reset(name: str):
    return engine("reset", name, timeout=45)


@app.post("/api/lab/reset")
def lab_reset():
    return engine("reset-all", timeout=180)


@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/credentials")
def credentials():
    e = _ENGINE_MOD.load_env() if _ENGINE_MOD else {}
    lab_pw = e.get("LAB_USER_PASSWORD", "Passw0rd!2026")
    return {"items": [
        {"label": "osTicket agent panel", "where": "http://localhost:8080/scp",
         "user": e.get("OSTICKET_ADMIN_USER", "ostadmin"),
         "password": e.get("OSTICKET_ADMIN_PASSWORD", "")},
        {"label": "Any of the 25 AD users", "where": "e.g. asloane · gokafor · ogrant · tlin",
         "user": "<the username>", "password": lab_pw},
        {"label": "SSH into a workstation", "where": "ssh -p 2201 asloane@localhost  (2201-2204)",
         "user": "assigned user or root", "password": lab_pw},
        {"label": "AD Domain Administrator", "where": "docker compose exec samba-dc …",
         "user": "Administrator", "password": e.get("AD_DOMAIN_ADMIN_PASSWORD", "")},
        {"label": "MariaDB root", "where": "docker compose exec mariadb mariadb -uroot -p…",
         "user": "root", "password": e.get("MARIADB_ROOT_PASSWORD", "")},
    ]}


# --------------------------------------------------------------- built-in shell
# An interactive bash in this container.  It has the docker CLI + compose plugin
# and the repo mounted at /lab, so the fixes the tickets ask for
# (`docker compose exec samba-dc …`) run verbatim.  Local-lab convenience only —
# anyone who can reach :3000 gets this shell.
TERMRC = "/app/termrc"


@app.websocket("/api/terminal")
async def terminal(ws: WebSocket):
    await ws.accept()
    pid, fd = pty.fork()
    if pid == 0:  # child
        os.environ.update(TERM="xterm-256color", HOME="/root",
                          LANG="C.UTF-8", COLUMNS="120", LINES="32")
        try:
            os.chdir(str(LAB_DIR))
        except OSError:
            pass
        args = ["bash", "--rcfile", TERMRC, "-i"] if os.path.exists(TERMRC) else ["bash", "-i"]
        os.execvp("bash", args)
        os._exit(1)

    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue()

    def _on_readable():
        try:
            data = os.read(fd, 65536)
        except OSError:
            data = b""
        queue.put_nowait(data)

    loop.add_reader(fd, _on_readable)

    async def _pump_out():
        while True:
            data = await queue.get()
            if not data:
                await ws.close()
                return
            try:
                await ws.send_bytes(data)
            except Exception:  # noqa: BLE001
                return

    out_task = asyncio.create_task(_pump_out())
    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if msg.get("bytes") is not None:
                os.write(fd, msg["bytes"])
            elif msg.get("text"):
                txt = msg["text"]
                if txt.startswith("{"):
                    try:
                        ctl = json.loads(txt)
                        if "resize" in ctl:
                            cols, rows = ctl["resize"]
                            fcntl.ioctl(fd, termios.TIOCSWINSZ,
                                        struct.pack("HHHH", rows, cols, 0, 0))
                            continue
                    except Exception:  # noqa: BLE001
                        pass
                os.write(fd, txt.encode())
    except WebSocketDisconnect:
        pass
    finally:
        loop.remove_reader(fd)
        out_task.cancel()
        for fn in (lambda: os.kill(pid, signal.SIGKILL),
                   lambda: os.close(fd),
                   lambda: os.waitpid(pid, 0)):
            try:
                fn()
            except OSError:
                pass


# ------------------------------------------------------------- static front end
if STATIC_DIR.exists():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")

    @app.get("/{full_path:path}")
    def spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(404, "not found")
        f = STATIC_DIR / full_path
        if f.is_file() and STATIC_DIR in f.resolve().parents:
            return FileResponse(f)
        # index.html must not be cached, or a redeploy leaves stale asset refs
        return FileResponse(STATIC_DIR / "index.html",
                            headers={"Cache-Control": "no-store"})
