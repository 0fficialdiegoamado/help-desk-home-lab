import React from "react";
import { dur } from "../lib.js";

const ICONS = {
  open: "M4 7h16M4 12h16M4 17h10",
  check: "M20 6 9 17l-5-5",
  clock: "M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
  alert: "M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z",
};

function Stat({ icon, tint, label, value, sub, alarm, big }) {
  return (
    <div className="card relative flex-1 basis-44 overflow-hidden px-4 py-3">
      <span className="absolute inset-y-0 left-0 w-[3px]" style={{ background: tint }} />
      <div className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-neutral-400">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d={ICONS[icon]} />
        </svg>
        {label}
      </div>
      <div
        className={`mt-1.5 font-semibold leading-none tabnum tracking-tight ${big ? "text-[26px]" : "text-[22px]"} ${
          alarm ? "text-rose-600 dark:text-rose-400" : big ? "text-emerald-600 dark:text-emerald-400" : "text-neutral-800 dark:text-neutral-100"
        }`}
      >
        {value}
      </div>
      {sub && <div className="mt-1 text-[10.5px] text-neutral-400">{sub}</div>}
    </div>
  );
}

export default function MetricsStrip({ m }) {
  const d = "—";
  return (
    <div className="flex flex-wrap gap-3">
      <Stat icon="check" tint="#10b981" label="Tickets you've solved" big
        value={m ? m.solved_today : d}
        sub={m && m.solved_total > m.solved_today ? `${m.solved_total} all-time` : "today"} />
      <Stat icon="open" tint="#6366f1" label="Open right now" value={m ? m.open_count : d} />
      <Stat icon="clock" tint="#0ea5e9" label="Avg time to fix"
        value={m && m.mttr_seconds != null ? dur(m.mttr_seconds) : d}
        sub="ticket filed → solved" />
      <Stat icon="alert" tint="#f43f5e" label="SLA breaches"
        value={m ? m.sla_breaches : d}
        alarm={m && m.sla_breaches > 0} />
    </div>
  );
}
