import React, { useState } from "react";
import { useLive } from "../lib.js";

function Copy({ value }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={() => {
        try {
          navigator.clipboard.writeText(value);
          setDone(true);
          setTimeout(() => setDone(false), 1200);
        } catch {
          /* ignore */
        }
      }}
      className="rounded p-1 text-neutral-400 transition hover:bg-neutral-100 hover:text-neutral-700 dark:hover:bg-neutral-800"
      title="copy"
    >
      {done ? (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 6 9 17l-5-5" />
        </svg>
      ) : (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="9" y="9" width="13" height="13" rx="2" />
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
        </svg>
      )}
    </button>
  );
}

export default function Credentials() {
  const { data } = useLive("/credentials", 60000);
  const items = data?.items || [];

  return (
    <details className="card group overflow-hidden">
      <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-3 text-[13px] font-medium text-neutral-600 transition hover:bg-neutral-50 dark:text-neutral-300 dark:hover:bg-neutral-800/40">
        <span className="flex items-center gap-2">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 18v3h3l11-11-3-3L2 18ZM14.5 6.5l3 3M15 3l6 6-3 3-6-6 3-3Z" />
          </svg>
          Logins &amp; passwords
        </span>
        <svg className="transition group-open:rotate-90" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="m9 18 6-6-6-6" />
        </svg>
      </summary>

      <div className="border-t border-neutral-100 dark:border-neutral-800">
        <p className="px-4 pt-3 text-[11px] text-neutral-400">
          Lab-only. Change them in <span className="font-mono">.env</span> and rebuild.
          The built-in terminal below needs no password.
        </p>
        <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
          {items.map((it) => (
            <div key={it.label} className="px-4 py-2.5">
              <div className="text-[12.5px] font-medium">{it.label}</div>
              <div className="mt-0.5 font-mono text-[11px] text-neutral-400">{it.where}</div>
              <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px]">
                <span className="text-neutral-500">
                  user <span className="font-mono text-neutral-700 dark:text-neutral-200">{it.user}</span>
                </span>
                <span className="flex items-center gap-1 text-neutral-500">
                  pass{" "}
                  <span className="rounded bg-neutral-100 px-1.5 py-0.5 font-mono text-neutral-800 dark:bg-neutral-800 dark:text-neutral-100">
                    {it.password}
                  </span>
                  <Copy value={it.password} />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </details>
  );
}
