import React, { useState } from "react";
import { marked } from "marked";
import { api, relTime } from "../lib.js";

function CopyButton({ text, label = "Copy" }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={() => {
        try {
          navigator.clipboard.writeText(text);
          setDone(true);
          setTimeout(() => setDone(false), 1400);
        } catch {
          /* ignore */
        }
      }}
      className="shrink-0 rounded-md bg-white/10 px-2 py-1 text-[11px] font-medium text-neutral-200 transition hover:bg-white/20"
    >
      {done ? "Copied ✓" : label}
    </button>
  );
}

function Solution({ name }) {
  const [md, setMd] = useState(null);
  const [err, setErr] = useState(null);
  React.useEffect(() => {
    api(`/scenarios/${name}/solution`)
      .then((d) => setMd(d.markdown))
      .catch((e) => setErr(e.message));
  }, [name]);
  if (err) return <p className="text-xs text-rose-500">{err}</p>;
  if (!md) return <p className="text-xs text-neutral-400">loading…</p>;
  return (
    <div
      className={[
        "max-w-none text-[12.5px] leading-relaxed text-neutral-600 dark:text-neutral-300",
        "[&_h1]:mt-0 [&_h1]:mb-1 [&_h1]:text-[13px] [&_h1]:font-semibold [&_h1]:text-neutral-800 dark:[&_h1]:text-neutral-100",
        "[&_h2]:mt-3 [&_h2]:mb-1 [&_h2]:text-[11px] [&_h2]:font-semibold [&_h2]:uppercase [&_h2]:tracking-wide [&_h2]:text-neutral-500",
        "[&_p]:mt-1.5 [&_ul]:mt-1.5 [&_li]:ml-4 [&_li]:list-disc [&_li]:mt-0.5",
        "[&_:not(pre)>code]:rounded [&_:not(pre)>code]:bg-neutral-100 [&_:not(pre)>code]:px-1 [&_:not(pre)>code]:py-0.5 [&_:not(pre)>code]:text-[11px] [&_:not(pre)>code]:text-neutral-700 dark:[&_:not(pre)>code]:bg-neutral-800 dark:[&_:not(pre)>code]:text-neutral-200",
        "[&_pre]:mt-1.5 [&_pre]:overflow-x-auto [&_pre]:rounded-lg [&_pre]:bg-neutral-900 [&_pre]:p-2.5 [&_pre]:text-[11px] [&_pre]:leading-relaxed",
        "[&_pre_code]:block [&_pre_code]:bg-transparent [&_pre_code]:p-0 [&_pre_code]:text-neutral-100",
      ].join(" ")}
      dangerouslySetInnerHTML={{ __html: marked.parse(md) }}
    />
  );
}

function IncidentCard({ s, onVerify, onReset, busy }) {
  const [pending, setPending] = useState(null);
  const [verdict, setVerdict] = useState(null);
  const [showFull, setShowFull] = useState(false);

  const run = (key, fn) => async () => {
    setPending(key);
    try {
      const r = await fn(s.name);
      if (key === "verify" && r) setVerdict(r.verdict);
      if (key === "reset") setVerdict(null);
    } finally {
      setPending(null);
    }
  };

  const fixed = verdict === "PASS";

  if (fixed) {
    return (
      <div className="card animate-fadeUp overflow-hidden border-emerald-300 bg-emerald-50/60 dark:border-emerald-500/30 dark:bg-emerald-500/10">
        <div className="flex items-center gap-3 p-4">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-emerald-500 text-white">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6 9 17l-5-5" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold text-emerald-800 dark:text-emerald-300">
              Solved — “{s.ticket_subject || s.title}”
            </div>
            <div className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80">
              root cause fixed and verified. It'll drop off in a moment.
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card overflow-hidden border-l-4 border-l-amber-400 dark:border-l-amber-500">
      <div className="p-4">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-[11px] text-neutral-400">
              <span className="rounded bg-indigo-50 px-1.5 py-0.5 font-semibold text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-300">
                NEW TICKET
              </span>
              {s.ticket_number && <span>#{s.ticket_number}</span>}
              {s.active_since && <span>· {relTime(s.active_since)}</span>}
            </div>
            <div className="mt-1.5 text-[15px] font-semibold leading-snug text-neutral-800 dark:text-neutral-100">
              “{s.ticket_subject || s.title}”
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px]">
              {s.department && (
                <span className="rounded-md bg-neutral-100 px-1.5 py-0.5 font-medium text-neutral-600 dark:bg-neutral-800 dark:text-neutral-300">
                  {s.department}
                </span>
              )}
              <span className="rounded-md bg-neutral-100 px-1.5 py-0.5 font-medium uppercase text-neutral-600 dark:bg-neutral-800 dark:text-neutral-300">
                {s.target}
              </span>
              <span className="text-neutral-500">
                {s.user_display || s.user} can't work until this is fixed
              </span>
            </div>
          </div>
          {verdict && (
            <span
              className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                fixed
                  ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400"
                  : "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-400"
              }`}
            >
              {fixed ? "FIXED ✓" : "NOT FIXED YET"}
            </span>
          )}
        </div>

        {/* one command: fix + check, so you get a big PASS/FAIL back */}
        {(() => {
          const oneLiner = s.fix
            ? `${s.fix} && scripts/verify.sh ${s.name}`
            : `scripts/verify.sh ${s.name}`;
          return (
            <div className="mt-3">
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-neutral-400">
                copy this → paste in the Terminal → Enter
              </div>
              <div className="flex items-center gap-2 overflow-hidden rounded-lg bg-neutral-900 p-2.5">
                <code className="flex-1 overflow-x-auto whitespace-pre font-mono text-[11.5px] leading-relaxed text-neutral-100">
                  {oneLiner}
                </code>
                <CopyButton text={oneLiner} label="Copy" />
              </div>
              <div className="mt-1.5 flex items-center gap-2 text-[11px] text-neutral-400">
                <span>it fixes it and prints a big green PASS (or red FAIL)</span>
                <span>·</span>
                <button
                  onClick={run("verify", onVerify)}
                  disabled={busy || pending}
                  className="font-medium text-indigo-600 hover:underline disabled:opacity-50 dark:text-indigo-400"
                >
                  {pending === "verify" ? "checking…" : "or just check it now"}
                </button>
              </div>
            </div>
          );
        })()}

        <div className="mt-2.5 flex items-center gap-3">
          <button
            onClick={() => setShowFull((v) => !v)}
            className="text-[11px] font-medium text-indigo-600 hover:underline dark:text-indigo-400"
          >
            {showFull ? "hide details" : "why / full write-up"}
          </button>
          <button
            onClick={run("reset", onReset)}
            disabled={busy || pending}
            className="ml-auto text-[11px] text-neutral-400 hover:text-neutral-600 disabled:opacity-50 dark:hover:text-neutral-300"
          >
            {pending === "reset" ? "clearing…" : "skip this one"}
          </button>
        </div>
      </div>

      {showFull && (
        <div className="animate-fadeUp border-t border-neutral-100 bg-neutral-50/60 px-4 py-3 dark:border-neutral-800 dark:bg-neutral-800/30">
          <Solution name={s.name} />
        </div>
      )}
    </div>
  );
}

export default function ActiveWork({ scenarios, busy, onVerify, onReset }) {
  // only show a card once the user has "filed the ticket" (a beat after the outage)
  const active = (scenarios.data?.scenarios || []).filter((s) => s.active && s.ticket_number);
  if (!active.length) return null;
  return (
    <div className="space-y-3">
      {active.map((s) => (
        <IncidentCard key={s.name} s={s} busy={busy} onVerify={onVerify} onReset={onReset} />
      ))}
    </div>
  );
}
