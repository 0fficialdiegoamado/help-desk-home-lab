import React, { useEffect } from "react";
import { dur } from "../lib.js";

export default function SolvedModal({ data, onClose, onNext, busy }) {
  useEffect(() => {
    if (!data) return;
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [data, onClose]);

  if (!data) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-neutral-900/50 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm animate-fadeUp overflow-hidden rounded-2xl border border-emerald-300 bg-white text-center shadow-pop dark:border-emerald-500/30 dark:bg-neutral-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-emerald-500 px-6 py-6 text-white">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-white/20">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6 9 17l-5-5" />
            </svg>
          </div>
          <div className="mt-3 text-lg font-bold tracking-tight">PASS — Solved</div>
          <div className="text-xs text-emerald-50/90">root cause fixed and verified</div>
        </div>

        <div className="px-6 py-5">
          <div className="text-[13px] font-semibold text-neutral-800 dark:text-neutral-100">
            “{data.subject}”
          </div>
          <div className="mt-1 text-[11px] text-neutral-500">
            {data.seconds != null ? `fixed in ${dur(data.seconds)}` : "cleared from your queue"}
            {data.solvedToday ? ` · ${data.solvedToday} solved today` : ""}
          </div>

          <div className="mt-5 flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 rounded-lg border border-neutral-300 bg-white px-3 py-2 text-xs font-medium text-neutral-700 transition hover:bg-neutral-50 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-200 dark:hover:bg-neutral-800"
            >
              Done
            </button>
            <button
              onClick={onNext}
              disabled={busy}
              className="flex-1 rounded-lg bg-indigo-600 px-3 py-2 text-xs font-semibold text-white transition hover:bg-indigo-500 disabled:opacity-60"
            >
              {busy ? "…" : "Next ticket →"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
