import React, { useState } from "react";

function Item({ s, busy, onFire }) {
  const [pending, setPending] = useState(false);
  const fire = async () => {
    setPending(true);
    try {
      await onFire(s.name);
    } finally {
      setPending(false);
    }
  };
  return (
    <div className="flex items-center justify-between gap-3 px-3.5 py-2.5">
      <div className="min-w-0">
        <div className="truncate text-[12.5px] font-medium">{s.title}</div>
        <div className="text-[11px] text-neutral-400">
          <span className="uppercase">{s.target}</span> · {s.user_display || s.user}
        </div>
      </div>
      {s.active ? (
        <span className="shrink-0 text-[11px] text-amber-600 dark:text-amber-400">
          active ↑
        </span>
      ) : (
        <button
          onClick={fire}
          disabled={busy || pending}
          className="shrink-0 rounded-md border border-neutral-300 bg-white px-2.5 py-1 text-[11px] font-medium text-neutral-700 transition hover:bg-neutral-50 disabled:opacity-50 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-200 dark:hover:bg-neutral-800"
        >
          {pending ? "…" : "Fire"}
        </button>
      )}
    </div>
  );
}

export default function ScenarioCatalog({ scenarios, busy, onFire }) {
  const list = scenarios.data?.scenarios || [];
  return (
    <details className="card group overflow-hidden">
      <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-3 text-[13px] font-medium text-neutral-600 transition hover:bg-neutral-50 dark:text-neutral-300 dark:hover:bg-neutral-800/40">
        <span>Or pick a specific scenario ({list.length})</span>
        <svg
          className="transition group-open:rotate-90"
          width="14" height="14" viewBox="0 0 24 24" fill="none"
          stroke="currentColor" strokeWidth="2" strokeLinecap="round"
        >
          <path d="m9 18 6-6-6-6" />
        </svg>
      </summary>
      <div className="divide-y divide-neutral-100 border-t border-neutral-100 dark:divide-neutral-800 dark:border-neutral-800">
        {list.map((s) => (
          <Item key={s.name} s={s} busy={busy} onFire={onFire} />
        ))}
      </div>
    </details>
  );
}
