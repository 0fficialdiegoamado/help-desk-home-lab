import React from "react";
import { STATUS, relTime } from "../lib.js";

function Bar({ pct }) {
  const p = Math.max(0, Math.min(100, pct ?? 0));
  const color =
    p >= 95 ? "bg-rose-500" : p >= 80 ? "bg-amber-500" : "bg-emerald-500";
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-neutral-200/80 dark:bg-neutral-800">
      <div
        className={`h-full rounded-full ${color} transition-all duration-500`}
        style={{ width: `${p}%` }}
      />
    </div>
  );
}

function Svc({ label, up }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-medium ${
        up
          ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
          : "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400"
      }`}
    >
      <span className={`h-1 w-1 rounded-full ${up ? "bg-emerald-500" : "bg-rose-500"}`} />
      {label}
    </span>
  );
}

function Card({ e }) {
  const st = STATUS[e.status] || STATUS.unknown;
  const disk = e.disk?.percent_used;
  const svc = e.services || {};
  const ad = e.ad_bind || {};

  return (
    <div className="card animate-fadeUp p-3.5">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{
                background: st.dot,
                "--ring": st.ring,
                animation: e.status === "red" ? "pulseRing 2s infinite" : "none",
              }}
            />
            <span className="font-semibold tracking-tight">{e.pc}</span>
          </div>
          <div className="mt-0.5 text-[11px] text-neutral-500">
            {e.assigned_user_name || e.assigned_user || "unassigned"}
            {e.department ? ` · ${e.department}` : ""}
          </div>
        </div>
        <span className={`text-[11px] font-semibold ${st.text}`}>{st.label}</span>
      </div>

      {e.reachable === false ? (
        <p className="mt-3 text-[12px] text-neutral-400">agent unreachable</p>
      ) : (
        <>
          <div className="mt-3">
            <div className="mb-1 flex items-center justify-between text-[11px] text-neutral-500">
              <span>disk</span>
              <span className="tabnum">{disk != null ? `${disk}%` : "—"}</span>
            </div>
            <Bar pct={disk} />
          </div>

          <div className="mt-3 flex flex-wrap gap-1.5">
            <Svc label="ssh" up={svc.ssh?.up} />
            <Svc label="cron" up={svc.cron?.up} />
            <Svc label="print" up={svc.print?.up} />
            <Svc label="dns" up={e.dns?.resolving} />
            <Svc label="ldap" up={ad.ldap?.ok} />
            <Svc label="krb" up={ad.kerberos?.ok} />
          </div>

          {e.status_reasons?.length > 0 && (
            <p className="mt-2.5 text-[11px] leading-snug text-amber-600 dark:text-amber-400">
              {e.status_reasons.join(" · ")}
            </p>
          )}

          <p className="mt-2 text-[10.5px] text-neutral-400">
            checked {relTime(e.checked_epoch)}
          </p>
        </>
      )}
    </div>
  );
}

export default function EndpointGrid({ state }) {
  const list = state.data?.endpoints || [];
  if (state.loading && !list.length)
    return <Skeleton />;
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
      {list.map((e) => (
        <Card key={e.pc} e={e} />
      ))}
    </div>
  );
}

function Skeleton() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="card h-40 animate-pulse" />
      ))}
    </div>
  );
}
