import React from "react";
import { useClock, dur, relTime } from "../lib.js";

function Countdown({ due, closed, is_open }) {
  const now = useClock();
  const ref = closed || now;
  const left = due - ref;
  const breached = left < 0 && is_open;
  const warn = left >= 0 && left < 3600 && is_open;

  let cls = "text-neutral-500";
  if (breached) cls = "text-rose-600 dark:text-rose-400 font-semibold";
  else if (warn) cls = "text-amber-600 dark:text-amber-400 font-medium";
  else if (!is_open) cls = "text-neutral-400";

  return (
    <span className={`tabnum text-[12px] ${cls}`}>
      {!is_open ? "closed" : breached ? `SLA ${dur(left)}` : dur(left)}
    </span>
  );
}

function Row({ t }) {
  return (
    <div className="flex items-center gap-3 px-3.5 py-2.5 transition hover:bg-neutral-50 dark:hover:bg-neutral-800/40">
      <span
        className="h-6 w-1 shrink-0 rounded-full"
        style={{ background: t.priority_color }}
        title={t.priority}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-[13px] font-medium">{t.subject}</span>
          {t.breached && t.is_open && (
            <span className="shrink-0 rounded bg-rose-100 px-1.5 py-0.5 text-[10px] font-semibold text-rose-700 dark:bg-rose-500/15 dark:text-rose-400">
              BREACH
            </span>
          )}
        </div>
        <div className="mt-0.5 truncate text-[11px] text-neutral-500">
          #{t.number} · {t.requester} · {t.dept || t.topic || "unrouted"} · {relTime(t.created)}
        </div>
      </div>
      <div className="shrink-0 text-right">
        <Countdown due={t.due} closed={t.closed} is_open={t.is_open} />
        <div className="text-[10px] text-neutral-400">{t.sla_name}</div>
      </div>
    </div>
  );
}

export default function TicketQueue({ state }) {
  const list = state.data?.tickets || [];
  if (state.loading && !list.length)
    return <div className="card h-64 animate-pulse" />;

  if (!list.length)
    return (
      <div className="card grid h-40 place-items-center text-sm text-neutral-400">
        queue is empty — fire a scenario below
      </div>
    );

  return (
    <div className="card divide-y divide-neutral-100 overflow-hidden dark:divide-neutral-800">
      {list.map((t) => (
        <Row key={t.number} t={t} />
      ))}
    </div>
  );
}
