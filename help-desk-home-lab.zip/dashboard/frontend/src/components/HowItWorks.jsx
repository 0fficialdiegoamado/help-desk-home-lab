import React, { useEffect, useState } from "react";
import { api } from "../lib.js";

const STEPS = [
  {
    n: 1,
    title: "Get a ticket",
    body:
      "Click “Give me a ticket”. A fault breaks one workstation and a ticket lands in the queue, written the way a real user would write it. The cause is never spelled out.",
  },
  {
    n: 2,
    title: "Work it out",
    body:
      "Read the ticket. See which workstation went amber or red. SSH in, poke at Active Directory with samba-tool. Figure out what actually broke.",
  },
  {
    n: 3,
    title: "Fix it for real",
    body:
      "Open the Terminal panel on the dashboard and run the fix — unlock the account, restart the service, correct the DNS setting. Not a workaround. Stuck? Each ticket has a “Show me the fix” link with the exact command.",
  },
  {
    n: 4,
    title: "Check your work",
    body:
      "Hit “Check my fix”. It confirms the underlying fault is gone — masking the symptom won't pass. Green means you nailed it.",
  },
];

export default function HowItWorks({ open, onClose, onDemo }) {
  const [firing, setFiring] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const runDemo = async () => {
    setFiring(true);
    try {
      await onDemo();
      onClose();
    } finally {
      setFiring(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-neutral-900/40 p-4 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className="my-8 w-full max-w-lg animate-fadeUp rounded-2xl border border-neutral-200 bg-white shadow-pop dark:border-neutral-800 dark:bg-neutral-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-neutral-100 px-5 py-4 dark:border-neutral-800">
          <div>
            <h2 className="text-[15px] font-semibold tracking-tight">How this lab works</h2>
            <p className="mt-0.5 text-xs text-neutral-500">
              A full IT help desk — osTicket, Active Directory, four workstations —
              that you break on purpose and practice fixing.
            </p>
          </div>
          <button
            onClick={onClose}
            className="shrink-0 rounded-md p-1 text-neutral-400 transition hover:bg-neutral-100 hover:text-neutral-700 dark:hover:bg-neutral-800"
            aria-label="close"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-4 px-5 py-4">
          {STEPS.map((s) => (
            <div key={s.n} className="flex gap-3">
              <div className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-indigo-600 text-[11px] font-semibold text-white">
                {s.n}
              </div>
              <div>
                <div className="text-[13px] font-semibold">{s.title}</div>
                <p className="mt-0.5 text-[12px] leading-relaxed text-neutral-500">{s.body}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-neutral-100 px-5 py-4 dark:border-neutral-800">
          <button
            onClick={onClose}
            className="rounded-lg border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 transition hover:bg-neutral-50 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-200 dark:hover:bg-neutral-800"
          >
            Close
          </button>
          <button
            onClick={runDemo}
            disabled={firing}
            className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-indigo-500 disabled:opacity-50"
          >
            {firing ? "…" : "Give me a ticket"}
          </button>
        </div>
      </div>
    </div>
  );
}
