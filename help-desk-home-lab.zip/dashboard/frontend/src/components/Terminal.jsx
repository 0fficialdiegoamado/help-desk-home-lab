import React, { useEffect, useRef, useState } from "react";
import { Terminal as XTerm } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";

const KEY = "helpdesk.terminal.open";

export default function Terminal() {
  const [open, setOpen] = useState(() => {
    try {
      return localStorage.getItem(KEY) === "1";
    } catch {
      return false;
    }
  });
  const [status, setStatus] = useState("connecting");
  const hostRef = useRef(null);
  const termRef = useRef(null);
  const wsRef = useRef(null);
  const fitRef = useRef(null);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, open ? "1" : "0");
    } catch {
      /* ignore */
    }
    if (!open) return;

    const term = new XTerm({
      fontFamily:
        'ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace',
      fontSize: 12.5,
      lineHeight: 1.3,
      cursorBlink: true,
      theme: {
        background: "#0c0c12",
        foreground: "#e4e4e7",
        cursor: "#a5b4fc",
        selectionBackground: "#4f46e555",
      },
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.open(hostRef.current);
    setTimeout(() => fit.fit(), 0);
    termRef.current = term;
    fitRef.current = fit;

    const proto = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${location.host}/api/terminal`);
    ws.binaryType = "arraybuffer";
    wsRef.current = ws;

    ws.onopen = () => {
      setStatus("connected");
      const send = () =>
        ws.readyState === 1 &&
        ws.send(JSON.stringify({ resize: [term.cols, term.rows] }));
      send();
    };
    ws.onmessage = (e) => term.write(new Uint8Array(e.data));
    ws.onclose = () => {
      setStatus("closed");
      term.write("\r\n\x1b[38;5;244m[session ended — collapse and reopen to reconnect]\x1b[0m\r\n");
    };
    ws.onerror = () => setStatus("error");

    term.onData((d) => ws.readyState === 1 && ws.send(d));
    term.onResize(({ cols, rows }) => {
      if (ws.readyState === 1) ws.send(JSON.stringify({ resize: [cols, rows] }));
    });

    const onWinResize = () => fit.fit();
    window.addEventListener("resize", onWinResize);

    return () => {
      window.removeEventListener("resize", onWinResize);
      try { ws.close(); } catch { /* */ }
      try { term.dispose(); } catch { /* */ }
      wsRef.current = null;
      termRef.current = null;
    };
  }, [open]);

  return (
    <div className="card overflow-hidden">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-4 py-3 text-left text-[13px] font-medium text-neutral-600 transition hover:bg-neutral-50 dark:text-neutral-300 dark:hover:bg-neutral-800/40"
      >
        <span className="flex items-center gap-2">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m4 17 6-6-6-6M12 19h8" />
          </svg>
          Terminal — run your fixes here
          {open && (
            <span
              className={`ml-1 inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${
                status === "connected"
                  ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400"
                  : status === "connecting"
                  ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400"
                  : "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-400"
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${
                status === "connected" ? "bg-emerald-500" : status === "connecting" ? "bg-amber-500" : "bg-rose-500"
              }`} />
              {status === "connected" ? "connected" : status === "connecting" ? "connecting…" : "disconnected — reopen"}
            </span>
          )}
        </span>
        <svg
          className={`transition ${open ? "rotate-90" : ""}`}
          width="14" height="14" viewBox="0 0 24 24" fill="none"
          stroke="currentColor" strokeWidth="2" strokeLinecap="round"
        >
          <path d="m9 18 6-6-6-6" />
        </svg>
      </button>
      {open && (
        <div className="border-t border-neutral-200 bg-[#0c0c12] p-2 dark:border-neutral-800">
          <div ref={hostRef} className="h-72 w-full" />
        </div>
      )}
    </div>
  );
}
