import React, { useState, useEffect, useRef } from "react";
import { useLive, api, relTime } from "./lib.js";

const AUTO_KEY = "helpdesk.autoTickets";
const AUTO_EVERY_MS = 5000; // how often auto-mode checks whether the queue is clear
                            // (a fault is then injected, and its ticket lands ~9-16s later)
import MetricsStrip from "./components/MetricsStrip.jsx";
import EndpointGrid from "./components/EndpointGrid.jsx";
import TicketQueue from "./components/TicketQueue.jsx";
import ActiveWork from "./components/ActiveWork.jsx";
import ScenarioCatalog from "./components/ScenarioCatalog.jsx";
import HowItWorks from "./components/HowItWorks.jsx";
import Terminal from "./components/Terminal.jsx";
import Credentials from "./components/Credentials.jsx";
import SolvedModal from "./components/SolvedModal.jsx";

export default function App() {
  const endpoints = useLive("/endpoints", 5000);
  const tickets = useLive("/tickets", 8000);
  const metrics = useLive("/metrics", 12000);
  const scenarios = useLive("/scenarios", 4000);
  const solvedLatest = useLive("/solved/latest", 3000);

  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);
  const [showHelp, setShowHelp] = useState(false);
  const [solved, setSolved] = useState(null);
  const [auto, setAuto] = useState(() => {
    try { return localStorage.getItem(AUTO_KEY) === "1"; } catch { return false; }
  });

  const flash = (msg, kind = "ok") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 4600);
  };

  const act = async (fn, okMsg) => {
    setBusy(true);
    try {
      const res = await fn();
      if (okMsg) flash(okMsg, "ok");
      return res;
    } catch (e) {
      flash(e.message || "something went wrong", "err");
    } finally {
      setBusy(false);
    }
  };

  const lastCheck = endpoints.data?.generated_at
    ? relTime(endpoints.data.generated_at)
    : "—";

  const scList = scenarios.data?.scenarios || [];
  const activeCount = scList.filter((s) => s.active).length;                 // fault injected (any)
  const openTickets = scList.filter((s) => s.active && s.ticket_number);      // ticket has landed
  const pending = scList.filter((s) => s.active && !s.ticket_number);        // outage now, ticket incoming
  const busyQueue = activeCount > 0;                                         // something unresolved

  const scListRef = useRef(scList);
  scListRef.current = scList;

  // pop the "Solved" modal whenever a PASS is recorded — including from the
  // terminal (`scripts/verify.sh`), not just the Check-my-fix button
  const seenSolvedAt = useRef(null);
  useEffect(() => {
    const d = solvedLatest.data;
    if (!d) return;
    const at = d.at || 0;
    if (seenSolvedAt.current === null) { seenSolvedAt.current = at; return; } // baseline
    if (at > seenSolvedAt.current) {
      seenSolvedAt.current = at;
      setSolved({ subject: d.subject, seconds: d.seconds, solvedToday: d.solved_today });
    }
  }, [solvedLatest.data]);

  useEffect(() => {
    try { localStorage.setItem(AUTO_KEY, auto ? "1" : "0"); } catch { /* */ }
    if (!auto) return;
    const tick = async () => {
      const list = scListRef.current || [];
      // strictly one ticket at a time: only fire when nothing is unresolved
      if (list.some((s) => s.active)) return;
      if (!list.some((s) => !s.active)) return;
      try { await api("/scenarios/random/run?only_when_clear=true", { method: "POST" }); } catch { /* */ }
    };
    const id = setInterval(tick, AUTO_EVERY_MS);
    const first = setTimeout(tick, 1200);
    return () => { clearInterval(id); clearTimeout(first); };
  }, [auto]);

  const eps = endpoints.data?.endpoints || [];
  const worst = eps.some((e) => e.status === "red")
    ? "red"
    : eps.some((e) => e.status === "amber")
    ? "amber"
    : eps.length
    ? "green"
    : "unknown";
  const sysLabel = { red: "Something's broken", amber: "Degraded", green: "All good", unknown: "…" }[worst];
  const sysColor = { red: "#ef4444", amber: "#f59e0b", green: "#10b981", unknown: "#a1a1aa" }[worst];

  const giveTicket = () =>
    act(async () => {
      const r = await api("/scenarios/random/run", { method: "POST" });
      flash("A workstation just went down — ticket incoming…", "ok");
      return r;
    });

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-5 sm:px-6 lg:px-8">
      <header className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-pop">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M4 7h16M4 12h16M4 17h10" />
            </svg>
          </div>
          <div>
            <h1 className="text-[17px] font-semibold leading-tight tracking-tight">Help Desk Lab</h1>
            <p className="max-w-lg text-xs leading-relaxed text-neutral-500">
              A real help desk you break on purpose. Get a ticket, work out what's
              wrong, fix it for real, and check your work.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setAuto((v) => !v)}
            title="Automatically file a new ticket every ~15s"
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium shadow-sm transition ${
              auto
                ? "border-emerald-400 bg-emerald-50 text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-300"
                : "border-neutral-300 bg-white text-neutral-600 hover:bg-neutral-50 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-300 dark:hover:bg-neutral-800"
            }`}
          >
            {auto && (
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
            )}
            {auto ? "Auto tickets: on" : "Auto tickets"}
          </button>
          <span className="hidden items-center gap-2 rounded-full border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium shadow-sm sm:inline-flex dark:border-neutral-800 dark:bg-neutral-900">
            <span
              className="h-2 w-2 rounded-full"
              style={{ background: sysColor, "--ring": `${sysColor}88`, animation: worst === "red" ? "pulseRing 2s infinite" : "none" }}
            />
            {sysLabel}
          </span>
          <button
            onClick={() => setShowHelp(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 shadow-sm transition hover:bg-neutral-50 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-200 dark:hover:bg-neutral-800"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" />
            </svg>
            How it works
          </button>
        </div>
      </header>

      <div className="mb-5 rounded-2xl border border-neutral-200 bg-white/70 p-4 text-[12.5px] leading-relaxed text-neutral-600 dark:border-neutral-800 dark:bg-neutral-900/50 dark:text-neutral-300">
        <span className="font-semibold text-neutral-800 dark:text-neutral-100">What this is: </span>
        a hands-on practice environment for IT / help-desk work. It runs a real ticketing
        system (osTicket), a real Active Directory domain (<span className="font-mono text-[11px]">helpdesk.lab</span>,
        25 users), and four Linux "workstations" — all in Docker on this machine.
        <br className="hidden sm:block" />
        <span className="font-semibold text-neutral-800 dark:text-neutral-100">What it does: </span>
        it breaks something on a workstation, then files a support ticket the way a
        confused user would write it — the cause is never spelled out. You diagnose it,
        fix the real problem in the built-in terminal, and it verifies you fixed the
        <em> root cause</em>, not just the symptom.
      </div>

      <HowItWorks
        open={showHelp}
        onClose={() => setShowHelp(false)}
        onDemo={async () => {
          await giveTicket();
        }}
      />

      <SolvedModal
        data={solved}
        busy={busy}
        onClose={() => setSolved(null)}
        onNext={async () => {
          setSolved(null);
          await giveTicket();
        }}
      />

      {/* ---- the one main action ---- */}
      {!busyQueue ? (
        <div className="card relative mb-5 overflow-hidden p-8 text-center">
          <div
            className="pointer-events-none absolute inset-x-0 -top-24 mx-auto h-48 w-[36rem] rounded-full opacity-60 blur-3xl"
            style={{ background: "radial-gradient(closest-side, rgba(99,102,241,.35), transparent)" }}
          />
          <div className="relative">
            <h2 className="text-base font-semibold tracking-tight">Ready when you are</h2>
            <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-neutral-500">
              Something breaks on a workstation, a ticket comes in a moment later,
              you fix it and check your work. One at a time.
            </p>
            <button
              onClick={giveTicket}
              disabled={busy}
              className="group mt-4 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-7 py-3.5 text-[15px] font-semibold text-white shadow-pop ring-4 ring-indigo-500/20 transition hover:-translate-y-0.5 hover:bg-indigo-500 hover:ring-indigo-500/30 active:translate-y-0 disabled:opacity-60"
            >
              {busy ? "Working…" : "Start a ticket"}
              {!busy && (
                <svg className="transition group-hover:translate-x-0.5" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              )}
            </button>
          </div>
        </div>
      ) : openTickets.length === 0 ? (
        <div className="mb-5 flex items-center gap-3 rounded-2xl border border-rose-300/70 bg-rose-50/70 p-4 dark:border-rose-500/30 dark:bg-rose-500/[0.08]">
          <span className="relative flex h-3 w-3 shrink-0">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-400 opacity-70" />
            <span className="relative inline-flex h-3 w-3 rounded-full bg-rose-500" />
          </span>
          <div>
            <div className="text-[13px] font-semibold text-rose-700 dark:text-rose-300">
              Something just broke for {pending[0]?.user_display || "a user"} on {(pending[0]?.target || "a workstation").toUpperCase()}
            </div>
            <p className="text-xs text-rose-600/90 dark:text-rose-400/90">
              They haven't raised it yet — the ticket lands in a few seconds. Check the
              workstations below for anything red or amber.
            </p>
          </div>
        </div>
      ) : (
        <div className="card mb-5 flex flex-wrap items-center justify-between gap-4 p-4">
          <div>
            <div className="text-[14px] font-semibold">
              {openTickets.length} ticket{openTickets.length > 1 ? "s" : ""} to work
            </div>
            <p className="mt-0.5 text-xs text-neutral-500">
              Fix it below, then <b>Check my fix</b>. The next ticket won't come until this one's done.
            </p>
          </div>
          <button
            onClick={() => act(() => api("/lab/reset", { method: "POST" }), "Everything reset")}
            disabled={busy}
            className="rounded-lg border border-neutral-300 bg-white px-3 py-2.5 text-xs font-medium text-neutral-600 transition hover:bg-neutral-50 disabled:opacity-50 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-300 dark:hover:bg-neutral-800"
          >
            Clear it
          </button>
        </div>
      )}

      <MetricsStrip m={metrics.data} />

      {openTickets.length > 0 && (
        <section className="mt-5 rounded-2xl border border-amber-300/70 bg-amber-50/50 p-3 dark:border-amber-500/25 dark:bg-amber-500/[0.06] sm:p-4">
          <div className="mb-3 flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-70" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-amber-500" />
            </span>
            <h2 className="text-[13px] font-bold uppercase tracking-wide text-amber-700 dark:text-amber-400">
              Your open work
            </h2>
            <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[11px] font-bold text-white">
              {openTickets.length} needs a fix
            </span>
          </div>
          <ActiveWork
            scenarios={scenarios}
            busy={busy}
            onVerify={async (n) => {
              const sc = scList.find((x) => x.name === n);
              const r = await act(() => api(`/scenarios/${n}/verify`, { method: "POST" }));
              if (r && r.verdict === "PASS") {
                const latest = await api("/solved/latest").catch(() => null);
                if (latest?.at) seenSolvedAt.current = latest.at; // dedupe the watcher
                setSolved({
                  subject: latest?.subject || sc?.ticket_subject || n,
                  seconds: latest?.seconds ?? (sc?.active_since ? Date.now() / 1000 - sc.active_since : null),
                  solvedToday: latest?.solved_today,
                });
              } else if (r) {
                flash("Not fixed yet — fix the cause, not just the symptom", "err");
              }
              return r;
            }}
            onReset={(n) => act(() => api(`/scenarios/${n}/reset`, { method: "POST" }), "Cleared")}
          />
        </section>
      )}

      <div className="mt-5 space-y-3">
        <Terminal />
        <Credentials />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-12">
        <section className="lg:col-span-5">
          <SectionTitle right={`updated ${lastCheck}`}>Workstations</SectionTitle>
          <EndpointGrid state={endpoints} />
        </section>
        <section className="lg:col-span-7">
          <SectionTitle
            right={tickets.data ? `${tickets.data.tickets.filter((t) => t.is_open).length} open` : null}
          >
            Ticket queue
          </SectionTitle>
          <TicketQueue state={tickets} />
        </section>
      </div>

      <div className="mt-5">
        <ScenarioCatalog
          scenarios={scenarios}
          busy={busy}
          onFire={(n) => act(() => api(`/scenarios/${n}/run`, { method: "POST" }), "Ticket filed — see “Your open work”")}
        />
      </div>

      <footer className="mt-8 pb-4 text-center text-[11px] text-neutral-400">
        queue is read-only · osTicket API only creates tickets, the DB is never written by this dashboard
      </footer>

      {toast && (
        <div
          className={`fixed bottom-5 left-1/2 z-[60] -translate-x-1/2 animate-fadeUp rounded-xl px-4 py-2.5 text-sm font-medium shadow-pop ${
            toast.kind === "err"
              ? "bg-rose-600 text-white"
              : "bg-neutral-900 text-white dark:bg-white dark:text-neutral-900"
          }`}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}

function SectionTitle({ children, right }) {
  return (
    <div className="mb-2.5 flex items-baseline justify-between">
      <h2 className="text-[13px] font-semibold uppercase tracking-wide text-neutral-500">{children}</h2>
      {right != null && <span className="text-xs font-medium text-neutral-400">{right}</span>}
    </div>
  );
}
