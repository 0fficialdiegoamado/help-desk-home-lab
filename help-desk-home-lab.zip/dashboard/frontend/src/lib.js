import React from "react";

export async function api(path, opts) {
  const r = await fetch(`/api${path}`, opts);
  if (!r.ok) throw new Error(`${r.status} ${path}`);
  return r.json();
}

export function useLive(path, ms) {
  const [state, setState] = React.useState({ data: null, error: null, loading: true });
  React.useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const data = await api(path);
        if (alive) setState({ data, error: null, loading: false });
      } catch (e) {
        if (alive) setState((s) => ({ ...s, error: e.message, loading: false }));
      }
    };
    tick();
    const id = setInterval(tick, ms);
    return () => { alive = false; clearInterval(id); };
  }, [path, ms]);
  return state;
}

// re-render every second for smooth countdowns
export function useClock() {
  const [, force] = React.useReducer((n) => n + 1, 0);
  React.useEffect(() => {
    const id = setInterval(force, 1000);
    return () => clearInterval(id);
  }, []);
  return Date.now() / 1000;
}

export function relTime(epoch) {
  if (!epoch) return "—";
  const s = Math.round(Date.now() / 1000 - epoch);
  if (s < 45) return "just now";
  if (s < 90) return "1 min ago";
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 5400) return "1 hr ago";
  if (s < 86400) return `${Math.round(s / 3600)} hr ago`;
  return `${Math.round(s / 86400)} d ago`;
}

export function dur(seconds) {
  if (seconds == null) return "—";
  const neg = seconds < 0;
  let s = Math.abs(Math.round(seconds));
  const d = Math.floor(s / 86400); s -= d * 86400;
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  let out;
  if (d) out = `${d}d ${h}h`;
  else if (h) out = `${h}h ${m}m`;
  else if (m) out = `${m}m ${s}s`;
  else out = `${s}s`;
  return neg ? `${out} over` : out;
}

export const STATUS = {
  green:  { dot: "#10b981", text: "text-emerald-600 dark:text-emerald-400", ring: "rgb(16 185 129 / 0.5)", label: "Healthy" },
  amber:  { dot: "#f59e0b", text: "text-amber-600 dark:text-amber-400",     ring: "rgb(245 158 11 / 0.5)", label: "Degraded" },
  red:    { dot: "#ef4444", text: "text-rose-600 dark:text-rose-400",       ring: "rgb(239 68 68 / 0.55)", label: "Down" },
  unknown:{ dot: "#a1a1aa", text: "text-neutral-500",                        ring: "transparent",           label: "Unknown" },
};
