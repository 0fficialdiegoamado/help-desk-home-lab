# expired-password — solution

**Root cause:** `gokafor`'s account has `pwdLastSet = 0` — the
*"user must change password at next logon"* flag. Until a real password is set,
every logon bounces straight back to the change-password prompt.

## How to spot it
```
docker compose exec samba-dc samba-tool user show gokafor --attributes=pwdLastSet
```
`pwdLastSet: 0`. (A normal account shows a large timestamp.)

## The fix
Set an actual password for the account (which clears the flag):
```
docker compose exec samba-dc samba-tool user setpassword gokafor \
  --newpassword='Passw0rd!2026'
```
In a real shop you'd hand the user a one-time password and let *them* set it;
here every lab user shares `LAB_USER_PASSWORD` from `.env`.

## What does *not* fix it (verify.sh will FAIL)
- "Just log in again" — `pwdLastSet` is still 0.
- Unlocking the account — it isn't locked.
- Clearing account expiry — that's a different attribute.

## Verify
```
scripts/verify.sh expired-password    # PASS = pwdLastSet != 0 AND account can auth
```
