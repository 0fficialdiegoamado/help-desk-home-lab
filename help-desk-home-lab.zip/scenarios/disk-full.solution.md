# disk-full — solution

**Root cause:** PC-03's working volume (`/scratch`, a 256 MB tmpfs standing in
for the local disk) is ~97% full. A large file —
`/scratch/outlook_archive.ost` — is eating the space, so apps can't write temp
files and everything crawls / fails to save.

## How to spot it
- `scripts/lab.sh health pc-03` → `status: red`, `disk.percent_used` ~97.
- On the box:
  ```
  docker compose exec pc-03 sh -c 'df -h /scratch; du -sh /scratch/* | sort -h'
  ```

## The fix
Free real space — delete the offending file (or archive it elsewhere):
```
docker compose exec pc-03 rm -f /scratch/outlook_archive.ost
```
A reboot also works here because `/scratch` is tmpfs (`docker compose restart pc-03`).

## What does *not* fix it (verify.sh will FAIL)
- Restarting the health agent or clearing its cache — frees nothing.
- Deleting unrelated small files.

## Verify
```
scripts/verify.sh disk-full           # PASS = /scratch < 85% used
```
