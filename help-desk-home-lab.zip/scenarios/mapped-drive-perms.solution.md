# mapped-drive-perms — solution

**Root cause:** the `[finance]` share definition on the DC had its
`valid users` changed from `@"HELPDESK\Finance-Share-RW"` to
`@"HELPDESK\Finance-Team"`. Everyone whose access came *through*
`Finance-Share-RW` (Sales reps, etc.) is now denied at connect time — it looks
like a per-user problem but it's the share config.

## How to spot it
```
docker compose exec samba-dc testparm -s 2>/dev/null | sed -n '/\[finance\]/,/^\[/p'
```
`valid users` is the wrong group. Multiple unrelated users report the same
"access denied" starting at the same time — a tell that it's server-side.

## The fix
Restore the correct group in `/etc/samba/smb.conf` and reload:
```
docker compose exec samba-dc sed -i \
  's|@"HELPDESK\\Finance-Team"|@"HELPDESK\\Finance-Share-RW"|' /etc/samba/smb.conf
docker compose exec samba-dc smbcontrol all reload-config
```

## What does *not* fix it (verify.sh will FAIL)
- Adding the complaining user to `Finance-Team`. It "works" for that one person
  but the share is still misconfigured for everyone else — the verify checks the
  effective `valid users` from `testparm`.

## Verify
```
scripts/verify.sh mapped-drive-perms  # PASS = share allows Finance-Share-RW AND a member can connect
```
