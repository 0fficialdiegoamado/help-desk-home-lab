# wrong-dns — solution

**Root cause:** PC-02's resolver is pointed at a **public DNS server**
(`9.9.9.9`) instead of the domain controller (`172.28.0.10`). Public DNS can't
answer for `helpdesk.lab`, so every internal name (file server, wiki, KDC)
fails while external sites keep working.

## How to spot it
- `scripts/lab.sh health pc-02` → `dns.resolving = false`,
  `dns.resolver` = `9.9.9.9`, `dns.expected_resolver` = `172.28.0.10`.
- On the box:
  ```
  docker compose exec pc-02 sh -c 'cat /etc/resolv.conf; host -t SRV _ldap._tcp.helpdesk.lab'
  ```

## The fix
Point the resolver back at the DC:
```
docker compose exec pc-02 sh -c 'printf "nameserver 172.28.0.10\nsearch helpdesk.lab\n" > /etc/resolv.conf'
```
(Real fix: correct DHCP scope options, or the static NIC config.)

## What does *not* fix it (verify.sh will FAIL)
- Hard-coding a few names in `/etc/hosts`. SRV records (`_ldap._tcp`, `_kerberos._udp`)
  still won't resolve, so domain auth stays broken — the verify checks an SRV lookup
  precisely to catch this shortcut.

## Verify
```
scripts/verify.sh wrong-dns           # PASS = resolv.conf points at the DC AND SRV records resolve
```
