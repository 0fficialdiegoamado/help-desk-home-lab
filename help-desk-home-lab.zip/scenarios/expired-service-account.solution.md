# expired-service-account — solution

**Root cause:** the `svc-scanner` service account has an **account expiry date
in the past** (`accountExpires`). Expired ≠ locked ≠ disabled ≠ bad password —
it's its own attribute, and it makes every authentication attempt fail.

## How to spot it
```
docker compose exec samba-dc samba-tool user show svc-scanner \
  --attributes=accountExpires,userAccountControl,badPwdCount
```
`accountExpires` is a real timestamp in the past (not `0` and not
`9223372036854775807`). `badPwdCount` is 0 and the lockout bit is clear — which
rules out the "usual suspects" and points at expiry.

## The fix
```
docker compose exec samba-dc samba-tool user setexpiry svc-scanner --noexpiry
```
Then re-run the failed job / restart the scanner service.

## What does *not* fix it (verify.sh will FAIL)
- Resetting the account's password. The credentials are fine; the account is
  expired. `kinit` still fails afterward.

## Verify
```
scripts/verify.sh expired-service-account   # PASS = accountExpires is 'never' AND svc-scanner can auth
```

## Prevention talking points
Service accounts should either never expire or be on a tracked renewal calendar
with alerting well before the date.
