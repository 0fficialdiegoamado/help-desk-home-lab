# locked-account — solution

**Root cause:** `asloane`'s AD account is **locked out**. Too many failed
Kerberos pre-auth attempts tripped the domain lockout policy
(threshold 5, duration 0 = stays locked until an admin clears it).

## How to spot it
- `scripts/lab.sh health pc-01` → Kerberos check fails with
  *"Clients credentials have been revoked"*.
- On the DC:
  ```
  docker compose exec samba-dc samba-tool user show asloane \
    --attributes=lockoutTime,badPwdCount,msDS-User-Account-Control-Computed
  ```
  `lockoutTime` is non-zero and `msDS-User-Account-Control-Computed` has the
  `0x10` (UF_LOCKOUT) bit set.

## The fix
```
docker compose exec samba-dc samba-tool user unlock asloane
```

## What does *not* fix it (verify.sh will FAIL)
- Resetting the password. A new password does not clear an existing lockout.
- Telling the user to "wait and try again" — duration is 0, it never auto-clears.

## Verify
```
scripts/verify.sh locked-account      # PASS = not locked AND can get a TGT
```

## Prevention talking points
Find the source of the bad auths (a stale mapped drive, a phone with an old
password, a service using cached creds) before it re-locks.
