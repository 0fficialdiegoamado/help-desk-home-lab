# group-removed — solution

**Root cause:** `ogrant` was removed from the **`Finance-Share-RW`** security
group. That group is what grants write access to `\\dc1\finance`, so she now
gets "permission denied" while colleagues who are still in the group are fine.

## How to spot it
```
docker compose exec samba-dc samba-tool user show ogrant --attributes=memberOf
docker compose exec samba-dc samba-tool group listmembers Finance-Share-RW
```
`ogrant` is missing from the group (and from her `memberOf` list).

## The fix
Put her back in the group:
```
docker compose exec samba-dc samba-tool group addmembers Finance-Share-RW ogrant
```
Group changes apply on the next logon / Kerberos ticket — have her sign out and
back in, or run `klist purge` / re-map the drive.

## What does *not* fix it (verify.sh will FAIL)
- Granting `ogrant` access some other way (adding her to `Finance-Team`, or a
  direct ACL on the folder). The verify checks `Finance-Share-RW` membership
  specifically — the intended access path must be restored.

## Verify
```
scripts/verify.sh group-removed       # PASS = ogrant in Finance-Share-RW AND can reach the share
```
