# mail-filter-blackhole — solution

**Root cause:** an osTicket **ticket filter** ("LAB blackhole ogrant") matches
`ogrant@helpdesk.lab` and its action is **Reject Ticket**. Her emails to the
help desk are silently dropped — no ticket, no auto-reply, no bounce. She only
got through this time by using the web form (the filter targets *Email*).

## How to spot it
- Admin panel → Manage → Ticket Filters → a rule matching her address with a
  Reject action.
- Or in the DB:
  ```
  docker compose exec mariadb mariadb -uroot -prootP@ss1 osticket -e "
    SELECT f.name, f.target, r.what, r.how, r.val, a.type
    FROM ost_filter f
    JOIN ost_filter_rule r ON r.filter_id=f.id
    JOIN ost_filter_action a ON a.filter_id=f.id
    WHERE f.isactive=1;"
  ```

## The fix
Disable or delete the filter (Admin panel → Manage → Ticket Filters, or):
```
docker compose exec mariadb mariadb -uroot -prootP@ss1 osticket \
  -e "UPDATE ost_filter SET isactive=0 WHERE name='LAB blackhole ogrant';"
```
(`rootP@ss1` is the MariaDB root password — see the "Logins & passwords" panel.)

## What does *not* fix it (verify.sh will FAIL)
- Manually creating the ticket she was trying to file. The next email is
  rejected too. The verify checks for the active reject rule itself.

## Verify
```
scripts/verify.sh mail-filter-blackhole   # PASS = no active reject-filter matches ogrant
```
