# print-service-down — solution

**Root cause:** the print spooler (`cupsd`) on PC-04 is not running, so print
jobs go nowhere. No error is shown to the user because the job never gets
queued.

## How to spot it
- `scripts/lab.sh health pc-04` → `services.print.up = false` (amber).
- On the box:
  ```
  docker compose exec pc-04 sh -c 'pgrep -x cupsd; lpstat -r'
  ```
  `lpstat -r` says *"scheduler is not running"*.

## The fix
Start the service:
```
docker compose exec pc-04 /usr/sbin/cupsd
```
(On a real workstation: `systemctl start cups` / `net start spooler`.)

## What does *not* fix it (verify.sh will FAIL)
- Restarting the user's session or the print dialog.
- Re-adding the printer — the spooler still isn't there to accept jobs.

## Verify
```
scripts/verify.sh print-service-down  # PASS = cupsd running AND scheduler accepting jobs
```
