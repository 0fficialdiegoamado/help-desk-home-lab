# clock-skew — solution

**Root cause:** PC-04's clock is **~11 minutes fast**. Kerberos allows a maximum
clock skew of 5 minutes between client and KDC; past that, every ticket request
is refused ("Clock skew too great"), so the user is re-prompted for credentials
constantly as cached tickets fail to renew.

*(In the lab the skew is simulated per-endpoint via `/scratch/clock_offset`,
which the health agent feeds to `faketime` for its Kerberos check — so the
host/VM clock is untouched.)*

## How to spot it
- `scripts/lab.sh health pc-04` → Kerberos check fails,
  `ad_bind.kerberos.detail` mentions *clock skew*, and
  `ad_bind.kerberos.clock_offset` shows `+11min`.
- On the box: `docker compose exec pc-04 cat /scratch/clock_offset`

## The fix
Resync the time (simulated):
```
docker compose exec pc-04 rm -f /scratch/clock_offset
```
Real fix: `w32tm /resync` (Windows) or `chronyc makestep` / fix the NTP source.

## What does *not* fix it (verify.sh will FAIL)
- Restarting the health agent, clearing the ticket cache, re-joining the domain —
  the clock is still wrong.

## Verify
```
scripts/verify.sh clock-skew          # PASS = no offset in effect AND kinit succeeds
```
