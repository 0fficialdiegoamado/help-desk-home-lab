-- ---------------------------------------------------------------------------
-- osTicket lab seed: departments, SLA plans, help topics, API key.
-- Idempotent -- every INSERT is guarded with NOT EXISTS on the natural name.
-- Applied by scripts/seed-osticket.sh (which sets @api_key / @api_ip / @prefix).
-- ---------------------------------------------------------------------------
SET @now = NOW();
SET @prefix = IFNULL(@prefix, 'ost_');

-- ============================ SLA plans ============================
-- grace_period is in HOURS. flags = 1 -> active.
INSERT INTO ost_sla (schedule_id, flags, grace_period, name, notes, created, updated)
SELECT 2, 1, 4,  'P1 - Critical (4h)',  'Site down / whole team blocked / security', @now, @now
 WHERE NOT EXISTS (SELECT 1 FROM ost_sla WHERE name='P1 - Critical (4h)');
INSERT INTO ost_sla (schedule_id, flags, grace_period, name, notes, created, updated)
SELECT 2, 1, 8,  'P2 - High (8h)',      'One user fully blocked from working',       @now, @now
 WHERE NOT EXISTS (SELECT 1 FROM ost_sla WHERE name='P2 - High (8h)');
INSERT INTO ost_sla (schedule_id, flags, grace_period, name, notes, created, updated)
SELECT 2, 1, 24, 'P3 - Normal (24h)',   'Degraded but has a workaround',             @now, @now
 WHERE NOT EXISTS (SELECT 1 FROM ost_sla WHERE name='P3 - Normal (24h)');
INSERT INTO ost_sla (schedule_id, flags, grace_period, name, notes, created, updated)
SELECT 2, 1, 72, 'P4 - Low (72h)',      'Request / question / nice-to-have',         @now, @now
 WHERE NOT EXISTS (SELECT 1 FROM ost_sla WHERE name='P4 - Low (72h)');

SET @sla_p1 = (SELECT id FROM ost_sla WHERE name='P1 - Critical (4h)');
SET @sla_p2 = (SELECT id FROM ost_sla WHERE name='P2 - High (8h)');
SET @sla_p3 = (SELECT id FROM ost_sla WHERE name='P3 - Normal (24h)');
SET @sla_p4 = (SELECT id FROM ost_sla WHERE name='P4 - Low (72h)');

-- ========================== Departments ==========================
INSERT INTO ost_department
  (pid, tpl_id, sla_id, schedule_id, email_id, autoresp_email_id, manager_id,
   flags, name, signature, ispublic, group_membership,
   ticket_auto_response, message_auto_response, path, updated, created)
SELECT NULL, 0, @sla_p3, 0, 0, 0, 0, 0, d.name, '', 1, 0, 1, 1, '/', @now, @now
FROM (
      SELECT 'Tier 1 - Service Desk' AS name
UNION SELECT 'Tier 2 - Endpoint Support'
UNION SELECT 'Identity & Access'
UNION SELECT 'Network Operations'
) d
WHERE NOT EXISTS (SELECT 1 FROM ost_department x WHERE x.name = d.name);

-- fix the materialized path for any freshly-inserted top-level dept
UPDATE ost_department SET path = CONCAT('/', id, '/') WHERE pid IS NULL AND path = '/';

SET @sla_p2_pre = (SELECT id FROM ost_sla WHERE name='P2 - High (8h)');
SET @dept_iam_pre = (SELECT id FROM ost_department WHERE name='Identity & Access');
-- route the stock "Access Issue" topic through Identity & Access / P2
UPDATE ost_help_topic
   SET dept_id = @dept_iam_pre, sla_id = @sla_p2_pre, priority_id = 3
 WHERE topic = 'Access Issue';

SET @dept_t1  = (SELECT id FROM ost_department WHERE name='Tier 1 - Service Desk');
SET @dept_t2  = (SELECT id FROM ost_department WHERE name='Tier 2 - Endpoint Support');
SET @dept_iam = (SELECT id FROM ost_department WHERE name='Identity & Access');
SET @dept_net = (SELECT id FROM ost_department WHERE name='Network Operations');

-- ========================== Help topics ==========================
-- priority_id: 1=low 2=normal 3=high 4=emergency (osTicket defaults)
INSERT INTO ost_help_topic
  (topic_pid, ispublic, noautoresp, flags, status_id, priority_id, dept_id,
   staff_id, team_id, sla_id, page_id, sequence_id, sort, topic, notes,
   created, updated)
SELECT 0, 1, 0, 0, 0, t.pri, t.dept, 0, 0, t.sla, 0, 0, 0, t.topic, '', @now, @now
FROM (
      SELECT 'Login / Account Locked'        AS topic, 3 AS pri, @dept_iam AS dept, @sla_p2 AS sla
UNION SELECT 'Password Reset / Expired',        2, @dept_iam, @sla_p2
UNION SELECT 'Group / Permission Change',       2, @dept_iam, @sla_p3
UNION SELECT 'File Share / Mapped Drive',       2, @dept_iam, @sla_p3
UNION SELECT 'Email Not Sending / Receiving',   3, @dept_t1,  @sla_p2
UNION SELECT 'Printing',                        2, @dept_t2,  @sla_p3
UNION SELECT 'Workstation / Hardware',          2, @dept_t2,  @sla_p3
UNION SELECT 'Disk Full / Performance',         2, @dept_t2,  @sla_p3
UNION SELECT 'Network / Cannot Reach Anything', 3, @dept_net, @sla_p2
UNION SELECT 'Software Install / Request',      1, @dept_t1,  @sla_p4
UNION SELECT 'Other / General Question',        1, @dept_t1,  @sla_p4
) t
WHERE NOT EXISTS (SELECT 1 FROM ost_help_topic x WHERE x.topic = t.topic);

-- ============================ API key ============================
INSERT INTO ost_api_key (isactive, ipaddr, apikey, can_create_tickets, can_exec_cron, notes, updated, created)
SELECT 1, @api_ip, @api_key, 1, 1, 'Lab scenario engine (scripts/run-scenario.sh)', @now, @now
 WHERE NOT EXISTS (SELECT 1 FROM ost_api_key WHERE apikey = @api_key);
-- keep the key's allowed source IP in sync if it was reconfigured
UPDATE ost_api_key SET ipaddr = @api_ip, isactive = 1 WHERE apikey = @api_key;

-- ===================== Default ticket SLA / dept =====================
-- point new/unrouted tickets at Tier 1 + P3 by default
UPDATE ost_config SET value = @dept_t1 WHERE `key` = 'default_dept_id'  AND namespace='core';
UPDATE ost_config SET value = @sla_p3  WHERE `key` = 'default_sla_id'   AND namespace='core';

SELECT
  (SELECT COUNT(*) FROM ost_sla)                     AS sla_plans,
  (SELECT COUNT(*) FROM ost_department)              AS departments,
  (SELECT COUNT(*) FROM ost_help_topic)              AS help_topics,
  (SELECT COUNT(*) FROM ost_api_key WHERE isactive=1) AS active_api_keys;
