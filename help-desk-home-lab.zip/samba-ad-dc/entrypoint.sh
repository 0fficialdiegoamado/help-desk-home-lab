#!/bin/bash
# Samba Active Directory Domain Controller for the help desk lab.
# Provisions the domain on first boot, then seeds OUs / groups / users.
set -euo pipefail

AD_REALM="${AD_REALM:-HELPDESK.LAB}"
AD_DOMAIN="${AD_DOMAIN:-HELPDESK}"
AD_ADMIN_PASSWORD="${AD_ADMIN_PASSWORD:-DomAdm!nP@ss1}"
AD_DNS_FORWARDER="${AD_DNS_FORWARDER:-1.1.1.1}"
DC_IP="${DC_IP:-$(hostname -i | awk '{print $1}')}"
REALM_LC="$(echo "$AD_REALM" | tr '[:upper:]' '[:lower:]')"
BASE_DN="dc=$(echo "$REALM_LC" | sed 's/\./,dc=/g')"

log() { echo "[dc] $*"; }

# --- DNS: point ourselves at Samba's internal resolver -----------------------
printf 'nameserver 127.0.0.1\nsearch %s\n' "$REALM_LC" > /etc/resolv.conf

SAMDB=/var/lib/samba/private/sam.ldb

if [ ! -f "$SAMDB" ]; then
    log "No domain found - provisioning $AD_REALM (NetBIOS $AD_DOMAIN) ..."
    rm -f /etc/samba/smb.conf
    samba-tool domain provision \
        --server-role=dc \
        --use-rfc2307 \
        --dns-backend=SAMBA_INTERNAL \
        --realm="$AD_REALM" \
        --domain="$AD_DOMAIN" \
        --adminpass="$AD_ADMIN_PASSWORD" \
        --host-ip="$DC_IP" \
        --option="dns forwarder = $AD_DNS_FORWARDER" \
        --option="ntlm auth = yes"

    # Kerberos config produced by the provision step
    cp -f /var/lib/samba/private/krb5.conf /etc/krb5.conf

    # Relax the password policy so lab accounts don't expire from under us.
    # (Individual scenarios re-tighten specific accounts on demand.)
    samba-tool domain passwordsettings set --complexity=off || true
    samba-tool domain passwordsettings set --history-length=0 || true
    samba-tool domain passwordsettings set --min-pwd-age=0 || true
    samba-tool domain passwordsettings set --max-pwd-age=0 || true
    samba-tool domain passwordsettings set --min-pwd-length=1 || true
    # A real lockout policy (the "locked account" scenario needs it). Duration 0
    # = stays locked until an admin runs `samba-tool user unlock`.
    samba-tool domain passwordsettings set \
        --account-lockout-threshold=5 \
        --account-lockout-duration=0 \
        --reset-account-lockout-after=15 || true

    # A CIFS share used by the "mapped drive permission denied" scenario.
    mkdir -p /srv/shares/finance
    chgrp -R users /srv/shares/finance 2>/dev/null || true
    chmod 0770 /srv/shares/finance
    if ! grep -q '^\[finance\]' /etc/samba/smb.conf; then
        cat >> /etc/samba/smb.conf <<'EOF'

[finance]
   path = /srv/shares/finance
   read only = no
   browseable = yes
   valid users = @"HELPDESK\Finance-Share-RW"
EOF
    fi
    log "Provision complete."
else
    log "Existing domain found - skipping provision."
    [ -f /var/lib/samba/private/krb5.conf ] && cp -f /var/lib/samba/private/krb5.conf /etc/krb5.conf
fi

# --- start Samba ------------------------------------------------------------
log "Starting samba ..."
samba -i &
SAMBA_PID=$!

# --- wait for LDAP to answer ----------------------------------------------
for i in $(seq 1 60); do
    if ldapsearch -x -H ldap://localhost -b '' -s base >/dev/null 2>&1; then
        break
    fi
    sleep 1
    [ "$i" = 60 ] && { log "LDAP never came up"; kill $SAMBA_PID; exit 1; }
done
log "LDAP is up."

# --- seed directory objects (idempotent) --------------------------------------
if [ ! -f /var/lib/samba/.seeded ]; then
    log "Seeding OUs, groups, users ..."
    BASE_DN="$BASE_DN" AD_DOMAIN="$AD_DOMAIN" /usr/local/bin/seed-ad.sh
    touch /var/lib/samba/.seeded
    log "Seed complete."
else
    log "Directory already seeded."
fi

log "Domain controller ready: $AD_REALM @ $DC_IP"
wait $SAMBA_PID
