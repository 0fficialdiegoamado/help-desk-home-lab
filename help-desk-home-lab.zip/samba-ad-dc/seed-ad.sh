#!/bin/bash
# Seed the helpdesk.lab directory: OUs, security groups, 25 users, service accounts.
# Idempotent - safe to re-run. Called by entrypoint.sh once per fresh volume.
set -uo pipefail

BASE_DN="${BASE_DN:?}"
AD_DOMAIN="${AD_DOMAIN:-HELPDESK}"
LAB_USER_PASSWORD="${LAB_USER_PASSWORD:-Passw0rd!2026}"
SVC_HEALTH_PASSWORD="${SVC_HEALTH_PASSWORD:-Health!P@ss1}"
SVC_SCANNER_PASSWORD="${SVC_SCANNER_PASSWORD:-Scanner!P@ss1}"
SVC_BACKUP_PASSWORD="${SVC_BACKUP_PASSWORD:-Backup!P@ss1}"
CSV=/opt/lab/users.csv

say() { echo "  [seed] $*"; }

ou() {  # ou "OU=Sales,OU=Departments"
    local dn="$1,$BASE_DN"
    samba-tool ou list 2>/dev/null | grep -qixF "$1,$BASE_DN" && return 0
    samba-tool ou create "$dn" >/dev/null 2>&1 && say "OU  $1" || true
}

grp() {  # grp <name> <ou-relative>
    local name="$1" gou="${2:-}"
    if samba-tool group list 2>/dev/null | grep -qixF "$name"; then return 0; fi
    if [ -n "$gou" ]; then
        samba-tool group add "$name" --groupou="$gou" >/dev/null 2>&1
    else
        samba-tool group add "$name" >/dev/null 2>&1
    fi
    say "group  $name"
}

usr() {  # usr <sam> <first> <last> <userou> <title>
    local sam="$1" first="$2" last="$3" uou="$4" title="$5"
    if samba-tool user list 2>/dev/null | grep -qixF "$sam"; then return 0; fi
    samba-tool user create "$sam" "$LAB_USER_PASSWORD" \
        --given-name="$first" --surname="$last" \
        --mail-address="${sam}@helpdesk.lab" \
        --job-title="$title" \
        --userou="$uou" >/dev/null 2>&1 \
        && say "user   $sam ($first $last)" \
        || { say "user   $sam FAILED"; return 1; }
    samba-tool user setexpiry "$sam" --noexpiry >/dev/null 2>&1 || true
}

member() {  # member <group> <sam>
    samba-tool group addmembers "$1" "$2" >/dev/null 2>&1 || true
}

# --- Organizational Units ---------------------------------------------------
ou "OU=Departments"
for d in Sales Engineering Finance Interns; do
    ou "OU=$d,OU=Departments"
done
ou "OU=Groups"
ou "OU=ServiceAccounts"

# --- Security groups -------------------------------------------------------
for g in Sales-Team Engineering-Team Finance-Team Interns-Team \
         Finance-Share-RW Print-Users VPN-Users; do
    grp "$g" "OU=Groups"
done

# --- Users from CSV ------------------------------------------------------
while IFS=, read -r sam first last dept group title; do
    case "$sam" in ''|\#*) continue ;; esac
    usr "$sam" "$first" "$last" "OU=$dept,OU=Departments" "$title" || continue
    member "$group" "$sam"
    # everyone gets print + VPN; endpoint owners also get the finance share
    member "Print-Users" "$sam"
    member "VPN-Users" "$sam"
done < "$CSV"

# Endpoint owners + finance staff can write the finance share
for u in ogrant pshah qross rbauer scole asloane; do
    member "Finance-Share-RW" "$u"
done

# --- Service accounts ----------------------------------------------------
svc() {  # svc <sam> <pass> <desc>
    local sam="$1" pass="$2" desc="$3"
    if samba-tool user list 2>/dev/null | grep -qixF "$sam"; then return 0; fi
    samba-tool user create "$sam" "$pass" \
        --description="$desc" \
        --userou="OU=ServiceAccounts" >/dev/null 2>&1 \
        && say "svc    $sam"
    samba-tool user setexpiry "$sam" --noexpiry >/dev/null 2>&1 || true
}
svc svc-health  "$SVC_HEALTH_PASSWORD"  "Endpoint health agent - LDAP/Kerberos probe"
svc svc-scanner "$SVC_SCANNER_PASSWORD" "Vulnerability scanner service account"
svc svc-backup  "$SVC_BACKUP_PASSWORD"  "Nightly backup service account"

# --- DNS: mail records so osTicket's e-mail domain check resolves -----------
# The DNS RPC service can lag LDAP by a few seconds on a cold boot - retry.
MAIL_IP="${MAIL_IP:-172.28.0.25}"
AUTH="Administrator%${AD_ADMIN_PASSWORD:-DomAdm!nP@ss1}"
dns_add() {  # dns_add <node> <type> <data> <label>
    for _ in $(seq 1 15); do
        if samba-tool dns add 127.0.0.1 helpdesk.lab "$1" "$2" "$3" -U "$AUTH" >/dev/null 2>&1; then
            say "dns    $4"; return 0
        fi
        # already exists? treat as success
        samba-tool dns query 127.0.0.1 helpdesk.lab "$1" "$2" -U "$AUTH" 2>/dev/null \
            | grep -qF "$3" && { say "dns    $4 (exists)"; return 0; }
        sleep 2
    done
    say "dns    $4 FAILED (non-fatal)"; return 0
}
dns_add mail A "$MAIL_IP"             "A  mail.helpdesk.lab -> $MAIL_IP"
dns_add @    MX "mail.helpdesk.lab 10" "MX helpdesk.lab -> mail.helpdesk.lab"

# --- Summary -------------------------------------------------------------
say "users:  $(samba-tool user list 2>/dev/null | grep -vc '^$')"
say "groups: $(samba-tool group list 2>/dev/null | grep -vc '^$')"
exit 0
