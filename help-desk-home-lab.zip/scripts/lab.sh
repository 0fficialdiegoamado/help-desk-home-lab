#!/bin/bash
# Convenience wrapper around the lab.  Run from anywhere.
#
#   scripts/lab.sh up | down | nuke | status | health [pc-01] | logs [svc] | sql [args]
#   scripts/lab.sh scenarios                 list scenarios
#   scripts/lab.sh run   <name> [opts]       inject fault + file ticket  (run-scenario.sh)
#   scripts/lab.sh verify <name>             PASS/FAIL root-cause check   (verify.sh)
#   scripts/lab.sh reset <name> | --all      undo a scenario / reset the lab
#   scripts/lab.sh active                    show active scenarios
set -euo pipefail
cd "$(dirname "$0")/.."

case "${1:-help}" in
  up)        docker compose up -d --build ;;
  down)      docker compose down ;;
  nuke)      docker compose down -v ;;              # wipe all state (AD, DB, tickets)
  logs)      shift; docker compose logs -f "$@" ;;
  status)    docker compose ps -a ;;
  health)    shift; python3 scripts/health.py "$@" ;;
  scenarios) python3 scripts/_engine.py list ;;
  run)       shift; python3 scripts/_engine.py run "$@" ;;
  verify)    shift; python3 scripts/_engine.py verify "$@" ;;
  reset)     shift; case "${1:-}" in --all|all) python3 scripts/_engine.py reset-all ;;
                                     *) python3 scripts/_engine.py reset "$@" ;; esac ;;
  active)    python3 scripts/_engine.py status ;;
  sql)
    shift
    pass=$(grep -E '^MARIADB_ROOT_PASSWORD=' .env | cut -d= -f2-)
    docker compose exec -T mariadb mariadb -uroot -p"$pass" --skip-ssl osticket "$@" ;;
  *)
    sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//' ;;
esac
