#!/usr/bin/env python3
"""Scenario engine for the help desk lab.

    _engine.py list
    _engine.py show    <name>
    _engine.py run     <name> [--now | --delay SECONDS] [--no-ticket]
    _engine.py verify  <name>
    _engine.py reset   <name>
    _engine.py status
    _engine.py reset-all

A scenario = scenarios/<name>.yaml (fault + ticket) plus scenarios/<name>.solution.md
(the answer -- never referenced by this engine).  The ticket text never names the
cause.  `verify` checks the *root cause* is gone; papering over the symptom fails.
"""
from __future__ import annotations

import json
import os
import random
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCEN_DIR = ROOT / "scenarios"
STATE_DIR = ROOT / ".labstate"
ENV_FILE = ROOT / ".env"

CONTAINERS = {
    "dc": "helpdesk-dc",
    "pc-01": "helpdesk-pc-01",
    "pc-02": "helpdesk-pc-02",
    "pc-03": "helpdesk-pc-03",
    "pc-04": "helpdesk-pc-04",
    "db": "helpdesk-mariadb",
    "osticket": "helpdesk-osticket",
}
ENDPOINT_IP = {
    "pc-01": "172.28.0.101", "pc-02": "172.28.0.102",
    "pc-03": "172.28.0.103", "pc-04": "172.28.0.104",
}

C_GREEN, C_RED, C_YELLOW, C_DIM, C_RESET = (
    "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m")


def banner(kind: str, title: str, detail: str = "") -> str:
    """A big coloured notification block for the terminal."""
    bg = "\033[30;42m" if kind == "pass" else "\033[97;41m"
    label = "PASS" if kind == "pass" else "FAIL"
    rows = [f"{label}  {title}"]
    for d in (detail or "").splitlines():
        d = d.strip()
        if d:
            rows.append("  " + d)
    w = max(len(r) for r in rows) + 4
    edge = bg + " " * w + C_RESET
    block = [edge] + [bg + " " + r.ljust(w - 2) + " " + C_RESET for r in rows] + [edge]
    return "\n" + "\n".join(block) + "\n"


# --------------------------------------------------------------------------- env
def load_env() -> dict:
    env = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env


ENV = load_env()


# ------------------------------------------------------------ tiny YAML loader
def load_yaml(text: str):
    """Supports: nested block mappings (2 levels), block scalars (`key: |`),
    flow lists of scalars (`[a, b]`), `#` full-line comments.  Enough for the
    scenario schema -- not a general parser."""
    lines = text.splitlines()
    root: dict = {}
    stack = [(-1, root)]           # (indent, container)
    i = 0
    while i < len(lines):
        raw = lines[i]
        if not raw.strip() or raw.lstrip().startswith("#"):
            i += 1
            continue
        indent = len(raw) - len(raw.lstrip())
        key, _, rest = raw.strip().partition(":")
        rest = rest.strip()
        while stack and stack[-1][0] >= indent:
            stack.pop()
        parent = stack[-1][1]

        if rest == "|":
            block, j = [], i + 1
            base = None
            while j < len(lines):
                bl = lines[j]
                if bl.strip() and (len(bl) - len(bl.lstrip())) <= indent:
                    break
                if bl.strip():
                    lead = len(bl) - len(bl.lstrip())
                    base = lead if base is None else min(base, lead)
                block.append(bl)
                j += 1
            base = base or 0
            while block and not block[-1].strip():
                block.pop()
            parent[key] = "\n".join(b[base:] if len(b) >= base else "" for b in block)
            i = j
            continue

        if rest == "":
            d: dict = {}
            parent[key] = d
            stack.append((indent, d))
            i += 1
            continue

        if not (rest[0] in "\"'[" ):        # strip trailing "  # comment"
            cut = rest.find(" #")
            if cut != -1:
                rest = rest[:cut].strip()
        parent[key] = _scalar(rest)
        i += 1
    return root


def _scalar(s: str):
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        return [_scalar(x.strip()) for x in inner.split(",")] if inner else []
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        return s[1:-1]
    low = s.lower()
    if low in ("true", "false"):
        return low == "true"
    try:
        return int(s)
    except ValueError:
        return s


# ---------------------------------------------------------------- scenario I/O
class Scenario:
    def __init__(self, name: str):
        self.name = name
        path = SCEN_DIR / f"{name}.yaml"
        if not path.exists():
            die(f"no scenario '{name}' (expected {path.relative_to(ROOT)})")
        self.d = load_yaml(path.read_text())
        self.d.setdefault("name", name)

    def __getitem__(self, k):
        return self.d.get(k)

    @property
    def target(self) -> str:
        return self.d.get("target", "dc")

    def block(self, section: str):
        """Return (context, script) for inject/verify/reset."""
        b = self.d.get(section) or {}
        if isinstance(b, str):
            return self.target, b
        return b.get("context", self.target), b.get("run", "")


def all_scenarios() -> list[str]:
    return sorted(p.stem for p in SCEN_DIR.glob("*.yaml"))


# ----------------------------------------------------------------- docker exec
def run_in(context: str, script: str, check=False) -> subprocess.CompletedProcess:
    container = CONTAINERS.get(context)
    if not container:
        die(f"unknown context '{context}'")
    if context == "db":
        pw = ENV.get("MARIADB_ROOT_PASSWORD", "rootP@ss1")
        cmd = ["docker", "exec", "-i", container,
               "mariadb", "-uroot", f"-p{pw}", "--skip-ssl", "-N",
               ENV.get("OSTICKET_DB_NAME", "osticket")]
        inp = script
    else:
        cmd = ["docker", "exec", "-i", container, "bash", "-se"]
        inp = "set -o pipefail\n" + expand(script)
    p = subprocess.run(cmd, input=inp, capture_output=True, text=True)
    if check and p.returncode != 0:
        sys.stderr.write(p.stdout + p.stderr)
        die(f"command in '{context}' failed (rc={p.returncode})")
    return p


def expand(script: str) -> str:
    """Make a few env values available to fault scripts as $VARS."""
    exports = "".join(
        f'export {k}={sh_quote(ENV.get(k, d))}\n' for k, d in (
            ("LAB_USER_PASSWORD", "Passw0rd!2026"),
            ("AD_DOMAIN_ADMIN_PASSWORD", "DomAdm!nP@ss1"),
            ("SVC_SCANNER_PASSWORD", "Scanner!P@ss1"),
            ("SVC_HEALTH_PASSWORD", "Health!P@ss1"),
        ))
    return exports + script


def sh_quote(s: str) -> str:
    return "'" + str(s).replace("'", "'\"'\"'") + "'"


# ----------------------------------------------------------------- osTicket API
def file_ticket(sc: Scenario) -> str:
    tk = sc["ticket"] or {}
    user = sc["user"] or "user"
    domain = "helpdesk.lab"
    payload = {
        "source": "API",
        "name": sc["user_display"] or user,
        "email": f"{user}@{domain}",
        "ip": ENDPOINT_IP.get(sc.target, "172.28.0.1"),
        "subject": tk.get("subject", sc["title"] or sc.name),
        "message": tk.get("body", ""),
        "topicId": int(sc["topic_id"] or 0),
        "priorityId": int(sc["priority"] or 2),
    }
    base = ENV.get("OSTICKET_API_URL") or os.environ.get("OSTICKET_API_URL") or "http://localhost:8080"
    req = urllib.request.Request(
        base.rstrip("/") + "/api/tickets.json",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json",
                 "X-API-Key": ENV.get("OSTICKET_API_KEY", "")},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read().decode().strip()
    except urllib.error.HTTPError as e:
        die(f"osTicket API rejected the ticket (HTTP {e.code}): {e.read().decode()[:300]}")
    except Exception as e:  # noqa: BLE001
        die(f"could not reach the osTicket API at {base}: {e}")


# ---------------------------------------------------------------------- state
def state_path(name: str) -> Path:
    return STATE_DIR / f"{name}.json"


def mark_active(name: str, info: dict):
    STATE_DIR.mkdir(exist_ok=True)
    state_path(name).write_text(json.dumps(info, indent=2))


SOLVED_LOG = STATE_DIR / "solved.jsonl"


def clear_active(name: str):
    state_path(name).unlink(missing_ok=True)


def record_solved(name: str):
    """Append a line to the solved log when a scenario is verified PASS."""
    info = {}
    try:
        info = json.loads(state_path(name).read_text())
    except (OSError, ValueError):
        pass
    STATE_DIR.mkdir(exist_ok=True)
    entry = {
        "name": name,
        "solved_at": time.time(),
        "injected_at": info.get("injected_at"),
        "ticket_number": info.get("ticket_number"),
    }
    with SOLVED_LOG.open("a") as fh:
        fh.write(json.dumps(entry) + "\n")


def solved_entries() -> list[dict]:
    if not SOLVED_LOG.exists():
        return []
    out = []
    for line in SOLVED_LOG.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def active() -> dict:
    out = {}
    if STATE_DIR.exists():
        for p in STATE_DIR.glob("*.json"):
            out[p.stem] = json.loads(p.read_text())
    return out


# --------------------------------------------------------------------- actions
def cmd_list(_):
    for n in all_scenarios():
        sc = Scenario(n)
        act = " " + C_YELLOW + "ACTIVE" + C_RESET if n in active() else ""
        print(f"  {n:24} P{sc['priority']}  {sc.target:5}  {sc['title']}{act}")


def cmd_show(args):
    sc = Scenario(args[0])
    print(json.dumps(sc.d, indent=2))


def cmd_run(args):
    name = args[0]
    opts = args[1:]
    sc = Scenario(name)
    delay = None
    if "--now" in opts:
        delay = 0
    elif "--delay" in opts:
        delay = int(opts[opts.index("--delay") + 1])
    lo, hi = (sc["delay"] or [20, 90])
    if delay is None:
        delay = random.randint(int(lo), int(hi))

    print(f"{C_DIM}scenario:{C_RESET} {name}  ->  {sc['title']}")
    ctx, script = sc.block("inject")
    print(f"{C_DIM}injecting fault in {ctx} ...{C_RESET}")
    run_in(ctx, script, check=True)
    print(f"  {C_GREEN}fault injected{C_RESET}")

    info = {"injected_at": time.time(), "title": sc["title"], "target": sc.target}

    if "--no-ticket" in opts:
        mark_active(name, info)
        print(f"{C_DIM}--no-ticket: skipping the ticket{C_RESET}")
        return

    if delay:
        print(f"{C_DIM}waiting {delay}s before the user notices and files a ticket ...{C_RESET}")
        time.sleep(delay)
    _do_file_ticket(name, sc, info)


def _do_file_ticket(name: str, sc: "Scenario", info: dict):
    resp = file_ticket(sc)
    num = resp if resp.isdigit() else "?"
    info["ticket_number"] = num
    mark_active(name, info)
    print(f"  {C_GREEN}ticket #{num} filed in osTicket{C_RESET}  ->  http://localhost:8080/scp/tickets.php")


def cmd_file_ticket(args):
    """File the osTicket ticket for a scenario whose fault is already injected."""
    name = args[0]
    sc = Scenario(name)
    info = active().get(name)
    if info is None:
        die(f"'{name}' is not active - inject the fault first")
    if info.get("ticket_number"):
        print(f"{C_DIM}ticket already filed (#{info['ticket_number']}){C_RESET}")
        return
    _do_file_ticket(name, sc, info)


def _verify_one(sc: "Scenario") -> bool:
    ctx, script = sc.block("verify")
    if not script.strip():
        die(f"scenario '{sc.name}' has no verify block")
    p = run_in(ctx, script)
    vb = sc["verify"] if isinstance(sc["verify"], dict) else {}
    detail = (p.stdout + p.stderr).strip()
    # Convention for db-context checks: the query SELECTs offending rows,
    # so "no rows" == root cause gone == PASS.
    ok = (p.returncode == 0) if ctx != "db" else (p.stdout.strip() == "" and p.returncode == 0)
    if ok:
        print(banner("pass", f"{sc.name} solved",
                     vb.get("explain_pass", "root cause is resolved")))
        if sc.name in active():
            record_solved(sc.name)
        clear_active(sc.name)
    else:
        print(banner("fail", f"{sc.name} — still broken",
                     vb.get("explain_fail", "root cause is still present")))
        if detail:
            print(C_DIM + indent(detail) + C_RESET)
    return ok


def cmd_verify(args):
    names = args or sorted(active())
    if not names:
        print("nothing to check - no scenario is active")
        sys.exit(0)
    results = [_verify_one(Scenario(n)) for n in names]
    sys.exit(0 if all(results) else 1)


def cmd_reset(args):
    sc = Scenario(args[0])
    ctx, script = sc.block("reset")
    if script.strip():
        print(f"{C_DIM}resetting {sc.name} in {ctx} ...{C_RESET}")
        run_in(ctx, script)
    clear_active(sc.name)
    print(f"  {C_GREEN}{sc.name} reset{C_RESET}")


def cmd_status(_):
    act = active()
    if not act:
        print("no active scenarios")
    else:
        print(f"{C_YELLOW}active scenarios:{C_RESET}")
        for n, info in sorted(act.items()):
            age = int(time.time() - info.get("injected_at", time.time()))
            tn = info.get("ticket_number", "-")
            print(f"  {n:24} ticket #{tn:8} injected {age}s ago  ({info.get('title','')})")


def cmd_reset_all(_):
    for n in list(active()) or all_scenarios():
        sc = Scenario(n)
        ctx, script = sc.block("reset")
        if script.strip():
            run_in(ctx, script)
        clear_active(n)
        print(f"  reset {n}")
    # wipe demo tickets + auto-created users, keep seed config
    run_in("db", """
        SET FOREIGN_KEY_CHECKS=0;
        TRUNCATE ost_ticket; TRUNCATE ost_thread; TRUNCATE ost_thread_entry;
        DELETE FROM ost_form_entry WHERE object_type IN ('T','U','A');
        DELETE FROM ost_user; DELETE FROM ost_user_email;
        SET FOREIGN_KEY_CHECKS=1;
    """)
    print(f"  {C_GREEN}tickets cleared, lab reset{C_RESET}")


def indent(s: str, pad="      "):
    return "\n".join(pad + ln for ln in s.splitlines())


def die(msg: str):
    sys.stderr.write(f"{C_RED}error:{C_RESET} {msg}\n")
    sys.exit(2)


COMMANDS = {
    "list": cmd_list, "show": cmd_show, "run": cmd_run, "verify": cmd_verify,
    "reset": cmd_reset, "status": cmd_status, "reset-all": cmd_reset_all,
    "file-ticket": cmd_file_ticket,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        sys.stderr.write(__doc__)
        sys.exit(2)
    cmd, rest = sys.argv[1], sys.argv[2:]
    if cmd in ("show", "run", "reset", "file-ticket") and not rest:
        die(f"'{cmd}' needs a scenario name (try: _engine.py list)")
    COMMANDS[cmd](rest)


if __name__ == "__main__":
    main()
