#!/bin/bash
# One-shot osTicket config seeder (runs inside a mariadb:11 container).
# Waits for the osTicket installer to finish creating its schema, then applies
# osticket/seed.sql. Idempotent -- safe on every `docker compose up`.
set -euo pipefail

DB_HOST="${DB_HOST:-172.28.0.20}"
DB_NAME="${DB_NAME:-osticket}"
API_KEY="${OSTICKET_API_KEY:?set OSTICKET_API_KEY}"
API_IP="${OSTICKET_API_IP:-172.28.0.1}"
# MYSQL_PWD is exported by compose -> mariadb client picks it up automatically
MYSQL=(mariadb -h "$DB_HOST" -u root --skip-ssl "$DB_NAME")

echo "[seed-osticket] waiting for osTicket schema on ${DB_HOST}/${DB_NAME} ..."
for i in $(seq 1 90); do
    if "${MYSQL[@]}" -N -e \
        "SELECT COUNT(*) FROM information_schema.tables
          WHERE table_schema='${DB_NAME}' AND table_name='ost_config';" \
        2>/dev/null | grep -q '^1$'; then
        # config table exists -- make sure the installer actually populated it
        if "${MYSQL[@]}" -N -e \
            "SELECT COUNT(*) FROM ost_config WHERE \`key\`='helpdesk_title';" \
            2>/dev/null | grep -qE '^[1-9]'; then
            echo "[seed-osticket] schema ready after ${i}0s-ish."
            break
        fi
    fi
    sleep 4
    if [ "$i" = 90 ]; then
        echo "[seed-osticket] timed out waiting for osTicket schema" >&2
        exit 1
    fi
done

echo "[seed-osticket] applying seed.sql ..."
{
    printf "SET @api_key='%s';\n" "$API_KEY"
    printf "SET @api_ip='%s';\n"  "$API_IP"
    printf "SET @prefix='ost_';\n"
    cat /seed/seed.sql
} | "${MYSQL[@]}" --table

# read-only DB user for the dashboard (Phase 3)
if [ -n "${DASHBOARD_DB_USER:-}" ]; then
    echo "[seed-osticket] ensuring read-only user '${DASHBOARD_DB_USER}' ..."
    "${MYSQL[@]}" -e "
        CREATE USER IF NOT EXISTS '${DASHBOARD_DB_USER}'@'%' IDENTIFIED BY '${DASHBOARD_DB_PASSWORD}';
        ALTER USER '${DASHBOARD_DB_USER}'@'%' IDENTIFIED BY '${DASHBOARD_DB_PASSWORD}';
        GRANT SELECT ON ${DB_NAME}.* TO '${DASHBOARD_DB_USER}'@'%';
        FLUSH PRIVILEGES;"
fi

echo "[seed-osticket] done."
