#!/bin/bash
# Inject a scenario's fault, wait a realistic beat, then file the ticket in osTicket.
#
#   scripts/run-scenario.sh <name>              random 20-90s delay before the ticket
#   scripts/run-scenario.sh <name> --now        file the ticket immediately
#   scripts/run-scenario.sh <name> --delay 5    fixed delay in seconds
#   scripts/run-scenario.sh <name> --no-ticket  inject only, no ticket
#   scripts/run-scenario.sh                     list all scenarios
set -euo pipefail
ENGINE="$(dirname "$0")/_engine.py"
if [ $# -eq 0 ]; then
  exec python3 "$ENGINE" list
fi
exec python3 "$ENGINE" run "$@"
