#!/usr/bin/env python3
"""Print a one-line health summary for each endpoint (or full JSON for one).

    scripts/health.py            all endpoints, one line each
    scripts/health.py pc-02      full JSON for one endpoint
"""
import json
import sys
import urllib.request

PORTS = {"pc-01": 9001, "pc-02": 9002, "pc-03": 9003, "pc-04": 9004}
DOT = {"green": "\033[32m●\033[0m", "amber": "\033[33m●\033[0m", "red": "\033[31m●\033[0m"}


def fetch(port):
    with urllib.request.urlopen(f"http://localhost:{port}/health", timeout=15) as r:
        return json.load(r)


def main():
    if len(sys.argv) > 1:
        name = sys.argv[1].lower()
        if name not in PORTS:
            sys.exit(f"unknown endpoint {name!r} (pc-01..pc-04)")
        print(json.dumps(fetch(PORTS[name]), indent=2))
        return
    for name, port in PORTS.items():
        try:
            d = fetch(port)
        except Exception as e:  # noqa: BLE001
            print(f"{name}  ?  agent not responding ({e})")
            continue
        s = d["services"]
        reasons = ", ".join(d["status_reasons"]) or "ok"
        print(f'{DOT.get(d["status"], "?")} {d["pc"]:6} {d["status"]:5} '
              f'{d["assigned_user"]:11} disk={d["disk"]["percent_used"]:>5}%  '
              f'ssh:{"up" if s["ssh"]["up"] else "DOWN"} '
              f'cron:{"up" if s["cron"]["up"] else "DOWN"} '
              f'print:{"up" if s["print"]["up"] else "DOWN"}  '
              f'ldap:{"ok" if d["ad_bind"]["ldap"]["ok"] else "FAIL"} '
              f'krb:{"ok" if d["ad_bind"]["kerberos"]["ok"] else "FAIL"}  {reasons}')


if __name__ == "__main__":
    main()
