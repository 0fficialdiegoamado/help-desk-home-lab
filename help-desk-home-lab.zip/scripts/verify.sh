#!/bin/bash
# Check that a scenario's ROOT CAUSE is actually gone.  Prints PASS or FAIL.
# Papering over the symptom fails.  Exit 0 = PASS, exit 1 = FAIL.
#
#   scripts/verify.sh <name>     check one scenario
#   scripts/verify.sh            check every scenario that is currently active
set -euo pipefail
exec python3 "$(dirname "$0")/_engine.py" verify "$@"
