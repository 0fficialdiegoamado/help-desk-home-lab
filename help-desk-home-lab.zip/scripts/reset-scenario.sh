#!/bin/bash
# Undo a scenario's fault (whatever state it's in) and clear its active marker.
#
#   scripts/reset-scenario.sh <name>     reset one scenario
#   scripts/reset-scenario.sh --all      reset every active scenario + clear demo tickets
set -euo pipefail
ENGINE="$(dirname "$0")/_engine.py"
case "${1:-}" in
  ""|-h|--help) echo "usage: scripts/reset-scenario.sh <name> | --all" >&2; exit 2 ;;
  --all|all)    exec python3 "$ENGINE" reset-all ;;
  *)            exec python3 "$ENGINE" reset "$1" ;;
esac
