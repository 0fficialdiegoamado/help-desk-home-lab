#!/bin/bash
# Endpoint container: one workstation = one assigned user.
# Runs sshd + cups + cron, then the health agent in the foreground.
set -uo pipefail

PC_NAME="${PC_NAME:-PC-00}"
ASSIGNED_USER="${ASSIGNED_USER:-user}"
ASSIGNED_USER_NAME="${ASSIGNED_USER_NAME:-Lab User}"
REALM="${REALM:-HELPDESK.LAB}"
DC_IP="${DC_IP:-172.28.0.10}"
DC_HOST="${DC_HOST:-dc1.helpdesk.lab}"
LAB_USER_PASSWORD="${LAB_USER_PASSWORD:-Passw0rd!2026}"
DOMAIN="${DOMAIN:-helpdesk.lab}"

log() { echo "[$PC_NAME] $*"; }

# --- Kerberos client config ------------------------------------------------
REALM_LC="$(echo "$REALM" | tr '[:upper:]' '[:lower:]')"
cat > /etc/krb5.conf <<EOF
[libdefaults]
    default_realm = ${REALM}
    dns_lookup_realm = false
    dns_lookup_kdc = true
    rdns = false
    ticket_lifetime = 24h
[realms]
    ${REALM} = {
        kdc = ${DC_IP}
        admin_server = ${DC_IP}
    }
    ${REALM_LC} = {
        kdc = ${DC_IP}
        admin_server = ${DC_IP}
    }
[domain_realm]
    .${DOMAIN} = ${REALM}
    ${DOMAIN} = ${REALM}
EOF

# --- DNS: resolve through the domain controller --------------------------
printf 'nameserver %s\nsearch %s\n' "$DC_IP" "$DOMAIN" > /etc/resolv.conf

# --- local login for the assigned user --------------------------------------
if ! id "$ASSIGNED_USER" >/dev/null 2>&1; then
    useradd -m -s /bin/bash -c "$ASSIGNED_USER_NAME" "$ASSIGNED_USER"
    echo "${ASSIGNED_USER}:${LAB_USER_PASSWORD}" | chpasswd
    usermod -aG sudo "$ASSIGNED_USER"
fi
echo "root:${LAB_USER_PASSWORD}" | chpasswd

# --- services -----------------------------------------------------------
mkdir -p /run/sshd
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
/usr/sbin/sshd
log "sshd started"

/usr/sbin/cron
log "cron started"

# cupsd standalone (no systemd in the container)
/usr/sbin/cupsd
log "cupsd started (print service)"

# --- health agent (foreground; keeps the container alive) ------------------
log "assigned to ${ASSIGNED_USER} (${ASSIGNED_USER_NAME}) - starting health agent on :9000"
exec python3 /usr/local/bin/agent.py
