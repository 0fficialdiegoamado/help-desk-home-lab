#!/usr/bin/env python3
"""Endpoint health agent.

Exposes JSON health on :9000 -- disk %, service up/down, DNS resolving,
AD bind (LDAP simple bind + Kerberos kinit).  Results are cached briefly so
a dashboard can poll aggressively without hammering the DC.

    GET /health   full report (also served at /)
"""
import json
import os
import shutil
import subprocess
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PC_NAME = os.environ.get("PC_NAME", "PC-00")
ASSIGNED_USER = os.environ.get("ASSIGNED_USER", "user")
ASSIGNED_USER_NAME = os.environ.get("ASSIGNED_USER_NAME", "Lab User")
DEPARTMENT = os.environ.get("DEPARTMENT", "")
DOMAIN = os.environ.get("DOMAIN", "helpdesk.lab")
REALM = os.environ.get("REALM", "HELPDESK.LAB")
DC_IP = os.environ.get("DC_IP", "172.28.0.10")
BIND_USER = os.environ.get("HEALTH_BIND_USER", "svc-health@helpdesk.lab")
BIND_PASS = os.environ.get("HEALTH_BIND_PASS", "")
PRINT_SERVICE = os.environ.get("PRINT_SERVICE", "cups")

BASE_DN = "dc=" + ",dc=".join(DOMAIN.split("."))
SCRATCH = "/scratch"
CLOCK_OFFSET_FILE = "/scratch/clock_offset"   # e.g. "+10min" -> clock-skew scenario
CACHE_TTL = 5.0

# process name -> friendly service label
SERVICE_PROCS = {
    "ssh": "sshd",
    "cron": "cron",
    "print": "cupsd",
}

_cache = {"ts": 0.0, "data": None}


def run(cmd, timeout=8, env=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, env=env)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    except Exception as e:  # noqa: BLE001
        return 125, str(e)


def check_disk():
    total, used, free = shutil.disk_usage(SCRATCH)
    pct = round(used / total * 100, 1) if total else 0.0
    return {
        "path": SCRATCH,
        "percent_used": pct,
        "free_mb": round(free / 1024 / 1024, 1),
        "total_mb": round(total / 1024 / 1024, 1),
    }


def check_services():
    out = {}
    for label, proc in SERVICE_PROCS.items():
        rc, _ = run(["pgrep", "-x", proc], timeout=4)
        out[label] = {"process": proc, "up": rc == 0}
    return out


def check_dns():
    # what resolver is the box actually configured to use?
    server = ""
    try:
        with open("/etc/resolv.conf") as fh:
            for line in fh:
                if line.startswith("nameserver"):
                    server = line.split()[1].strip()
                    break
    except OSError:
        pass

    # internal name must resolve *through the box's own resolver* -- this is what
    # breaks when resolv.conf points at the wrong server
    rc_int, out_int = run(["host", "-W", "3", DOMAIN], timeout=6)
    internal_ok = rc_int == 0 and "has address" in out_int

    # is the DC's DNS itself answering (asked directly)?
    rc_dc, out_dc = run(["host", "-W", "3", DOMAIN, DC_IP], timeout=6)
    dc_ok = rc_dc == 0 and "has address" in out_dc

    rc_ext, out_ext = run(["host", "-W", "3", "example.com"], timeout=6)
    external_ok = rc_ext == 0 and "has address" in out_ext
    return {
        "resolving": internal_ok,
        "internal_query": DOMAIN,
        "external_resolving": external_ok,
        "dc_dns_ok": dc_ok,
        "resolver": server,
        "expected_resolver": DC_IP,
    }


def _faketime_env():
    """Honour /scratch/clock_offset for the Kerberos check (clock-skew scenario)."""
    env = dict(os.environ)
    try:
        with open(CLOCK_OFFSET_FILE) as fh:
            offset = fh.read().strip()
    except OSError:
        return env, ""
    if not offset:
        return env, ""
    for cand in (
        "/usr/lib/aarch64-linux-gnu/faketime/libfaketime.so.1",
        "/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1",
    ):
        if os.path.exists(cand):
            env["LD_PRELOAD"] = cand
            env["FAKETIME"] = offset
            return env, offset
    return env, offset


def check_ad_bind():
    result = {"ldap": {"ok": False}, "kerberos": {"ok": False}}

    # 1. LDAP simple bind against the DC.  Samba AD rejects plaintext binds
    #    ("strong auth required"), so bind over LDAPS.
    ldap_env = dict(os.environ)
    ldap_env["LDAPTLS_REQCERT"] = "never"
    rc, out = run([
        "ldapsearch", "-x", "-o", "nettimeout=6",
        "-H", f"ldaps://{DC_IP}",
        "-D", BIND_USER, "-w", BIND_PASS,
        "-b", BASE_DN, "-s", "base", "dn",
    ], timeout=10, env=ldap_env)
    result["ldap"]["ok"] = rc == 0
    if rc != 0:
        result["ldap"]["detail"] = out.strip().splitlines()[-1][:200] if out.strip() else "no response"

    # 2. Kerberos AS-REQ (sensitive to clock skew, lockout, password expiry).
    #    Principal realm is case-sensitive -- force the UPN realm to upper case.
    if "@" in BIND_USER:
        _u, _r = BIND_USER.rsplit("@", 1)
        krb_principal = f"{_u}@{_r.upper()}"
    else:
        krb_principal = f"{BIND_USER}@{REALM}"
    env, offset = _faketime_env()
    ccache = "/tmp/agent_krb5cc"
    env["KRB5CCNAME"] = f"FILE:{ccache}"
    try:
        p = subprocess.run(["kinit", krb_principal], input=BIND_PASS + "\n",
                           capture_output=True, text=True, timeout=12, env=env)
        result["kerberos"]["ok"] = p.returncode == 0
        if p.returncode != 0:
            msg = (p.stderr or p.stdout or "").strip().splitlines()
            result["kerberos"]["detail"] = msg[-1][:200] if msg else "kinit failed"
    except Exception as e:  # noqa: BLE001
        result["kerberos"]["detail"] = str(e)
    finally:
        run(["kdestroy", "-c", f"FILE:{ccache}"], timeout=4)
    if offset:
        result["kerberos"]["clock_offset"] = offset
    return result


def _status(disk, services, dns, ad):
    reasons = []
    if not services["ssh"]["up"]:
        reasons.append("sshd down")
    if not dns["resolving"]:
        reasons.append("cannot resolve internal DNS")
    if not ad["ldap"]["ok"]:
        reasons.append("AD LDAP bind failing")
    if disk["percent_used"] >= 95:
        reasons.append("disk critically full")
    if reasons:
        return "red", reasons

    if not ad["kerberos"]["ok"]:
        reasons.append("Kerberos auth failing")
    if not services["print"]["up"]:
        reasons.append("print service down")
    if not services["cron"]["up"]:
        reasons.append("cron down")
    if disk["percent_used"] >= 80:
        reasons.append("disk usage high")
    if not dns["external_resolving"]:
        reasons.append("no external DNS resolution")
    if reasons:
        return "amber", reasons
    return "green", []


def build_report():
    disk = check_disk()
    services = check_services()
    dns = check_dns()
    ad = check_ad_bind()
    status, reasons = _status(disk, services, dns, ad)
    return {
        "pc": PC_NAME,
        "assigned_user": ASSIGNED_USER,
        "assigned_user_name": ASSIGNED_USER_NAME,
        "department": DEPARTMENT,
        "domain": DOMAIN,
        "checked_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "checked_epoch": int(time.time()),
        "status": status,
        "status_reasons": reasons,
        "disk": disk,
        "services": services,
        "dns": dns,
        "ad_bind": ad,
    }


def get_report():
    now = time.time()
    if _cache["data"] is None or now - _cache["ts"] > CACHE_TTL:
        _cache["data"] = build_report()
        _cache["ts"] = now
    return _cache["data"]


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, payload):
        body = json.dumps(payload, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path.rstrip("/") in ("", "/health"):
            self._send(200, get_report())
        elif self.path.rstrip("/") == "/ping":
            self._send(200, {"pong": True, "pc": PC_NAME})
        else:
            self._send(404, {"error": "not found"})

    def log_message(self, *_):  # quiet
        return


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", 9000), Handler).serve_forever()
