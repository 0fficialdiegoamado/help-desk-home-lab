# Help Desk Home Lab

A self-contained IT help desk on one machine: a real ticketing system, a real
Active Directory, four "user workstations" you can break, and (Phase 3) a web
dashboard. Everything runs in Docker. One command brings it up.

> **Status:** all three phases complete — core stack, scenario engine, and the
> web dashboard at **http://localhost:3000**. One `docker compose up -d`.

---

## What's in the box (Phase 1)

| Service        | What it is                                   | URL / access                         |
|----------------|----------------------------------------------|--------------------------------------|
| `osticket`     | osTicket 1.14 ticketing system               | http://localhost:8080                |
| `mariadb`      | Database behind osTicket                      | `localhost` via `scripts/lab.sh sql` |
| `samba-dc`     | Active Directory DC for **helpdesk.lab**      | LDAP/Kerberos on `172.28.0.10`       |
| `pc-01..pc-04` | Endpoint workstations (sshd + health agent)   | ssh `localhost:2201..2204`, health `:9001..9004` |
| `dashboard`    | React + FastAPI ops dashboard                 | **http://localhost:3000**            |
| `mailpit`      | Catch-all SMTP + webmail (for mail scenarios) | http://localhost:8025                |

### The domain

- **Realm:** `HELPDESK.LAB`  **NetBIOS:** `HELPDESK`
- **25 users** in `OU=Departments` → `OU=Sales | Engineering | Finance | Interns`
- **Security groups** in `OU=Groups`: `Sales-Team`, `Engineering-Team`,
  `Finance-Team`, `Interns-Team`, `Finance-Share-RW`, `Print-Users`, `VPN-Users`
- **Service accounts** in `OU=ServiceAccounts`: `svc-health` (used by the endpoint
  agents), `svc-scanner`, `svc-backup`
- A CIFS share `\\dc1\finance` restricted to `Finance-Share-RW`
- Password policy complexity is **off** and accounts are set to never expire, so
  nothing breaks on its own — the Phase 2 scenarios re-tighten specific accounts
  on demand.

### Endpoints

Each `pc-0X` container is one workstation assigned to one user:

| Host  | User      | Name          | Dept        | ssh                    | health                       |
|-------|-----------|---------------|-------------|------------------------|------------------------------|
| PC-01 | `asloane` | Aaron Sloane  | Sales       | `ssh asloane@localhost -p 2201` | http://localhost:9001/health |
| PC-02 | `gokafor` | Grace Okafor  | Engineering | `ssh gokafor@localhost -p 2202` | http://localhost:9002/health |
| PC-03 | `ogrant`  | Olivia Grant  | Finance     | `ssh ogrant@localhost -p 2203`  | http://localhost:9003/health |
| PC-04 | `tlin`    | Tara Lin      | Interns     | `ssh tlin@localhost -p 2204`    | http://localhost:9004/health |

The **health agent** on `:9000` (published as `:9001..9004`) returns JSON:

```json
{
  "pc": "PC-01", "assigned_user": "asloane", "status": "green",
  "status_reasons": [],
  "disk":     { "path": "/scratch", "percent_used": 1.2, "free_mb": 252.0 },
  "services": { "ssh": {"up": true}, "cron": {"up": true}, "print": {"up": true} },
  "dns":      { "resolving": true, "resolver": "172.28.0.10", "external_resolving": true },
  "ad_bind":  { "ldap": {"ok": true}, "kerberos": {"ok": true} }
}
```

`status` is `green` / `amber` / `red`:

- **red** — sshd down, internal DNS broken, AD LDAP(S) bind failing, or `/scratch` ≥ 95 %
- **amber** — Kerberos failing, print/cron down, disk ≥ 80 %, or no external DNS
- **green** — all clear

The LDAP check binds over **LDAPS** (Samba AD rejects plaintext binds); the
Kerberos check does a real `kinit` as `svc-health`, so it trips on clock skew,
lockout, and password expiry — which is what several Phase 2 scenarios exercise.

---

## Setup

**Requirements:** Docker with Compose v2. On Apple Silicon the lab is developed on
[Colima](https://github.com/abiosoft/colima); give the VM at least **4 CPU / 6 GB**:

```sh
colima start --cpu 4 --memory 6 --disk 40
```

The `osticket` image is `linux/amd64` and runs under emulation on Apple Silicon
(its PHP installer runs once on first boot). Everything else is arm64-native.
A clean `docker compose up -d` reaches "all healthy" in about **90 seconds** on
an M-series Mac after images are built.

```sh
cd helpdesk-lab
# (optional) edit .env to change passwords
docker compose up -d --build      # or: scripts/lab.sh up
```

First run pulls/builds images (~5–10 min) and then:

1. `mariadb` comes up, `osticket` installs itself from the `.env` values.
2. `samba-dc` provisions `helpdesk.lab` and seeds OUs / groups / 25 users.
3. `osticket-seed` waits for osTicket, then adds departments / SLA plans / help
   topics / the API key, and exits.
4. `pc-01..04` join the party once the DC is healthy.

Watch it settle:

```sh
docker compose ps                 # everything "healthy" / seed "exited (0)"
scripts/lab.sh health             # one line per endpoint
```

### Verify Phase 1

```sh
scripts/lab.sh status          # 8 services "healthy", osticket-seed "Exited (0)"
scripts/lab.sh health          # 4 endpoints, all green

# osTicket up + seeded
curl -sI localhost:8080 | head -1                       # HTTP 200
scripts/lab.sh sql -N -e \
  "SELECT name FROM ost_sla WHERE id>1; SELECT topic FROM ost_help_topic WHERE topic_id>=11;"

# AD: 25 users in OUs, group membership, mail DNS
docker compose exec samba-dc samba-tool user list | sort
docker compose exec samba-dc samba-tool group listmembers Finance-Team
docker compose exec pc-01 host -t MX helpdesk.lab

# an endpoint binds to AD (LDAPS) + Kerberos and resolves internal DNS
scripts/lab.sh health pc-01

# ssh into a workstation (password = LAB_USER_PASSWORD in .env)
ssh -p 2201 asloane@localhost

# file a ticket through the API the way Phase 2 will (should print a number)
curl -s -X POST http://localhost:8080/api/tickets.json \
  -H "X-API-Key: $(grep OSTICKET_API_KEY .env | cut -d= -f2)" \
  -H 'Content-Type: application/json' \
  -d '{"source":"API","name":"Aaron Sloane","email":"asloane@helpdesk.lab","ip":"172.28.0.101","topicId":12,"subject":"cant log in","message":"it says my account is locked"}'
```

All of the above was run against a clean `docker compose up -d` while building
Phase 1.

---

## Credentials

All lab-only. Everything lives in **`.env`** — change values there, then
`docker compose down -v && docker compose up -d`.

| Account                         | Username                | Password (default)   |
|---------------------------------|-------------------------|----------------------|
| osTicket admin (Agent panel)    | `ostadmin`              | `Adm!nP@ss1`         |
| osTicket admin panel URL        | http://localhost:8080/scp |                    |
| AD Domain Administrator         | `Administrator`         | `DomAdm!nP@ss1`      |
| All 25 AD users                 | e.g. `asloane`          | `Passw0rd!2026`      |
| Endpoint login (SSH) — assigned user + `root` | `asloane` / `root` | `Passw0rd!2026` |
| MariaDB root                    | `root`                  | `rootP@ss1`          |
| MariaDB osticket user           | `osticket`              | `ostP@ss1`           |
| MariaDB dashboard user (SELECT) | `dashboard`             | `dashRO!1`           |
| Service account `svc-health`    | `svc-health@helpdesk.lab` | `Health!P@ss1`     |
| osTicket API key (Phase 2)      | header `X-API-Key`      | see `OSTICKET_API_KEY` in `.env` |

---

## Scenario engine (Phase 2)

Ten fault scenarios in `scenarios/`, one YAML each. Each has a matching
`<name>.solution.md` with the answer — **the ticket text never names the cause.**

| scenario | target | what the user sees |
|---|---|---|
| `locked-account`          | pc-01 asloane | AD account locked out |
| `expired-password`        | pc-02 gokafor | "must change password at next logon" loop |
| `disk-full`               | pc-03 ogrant  | workstation out of disk, apps freezing |
| `print-service-down`      | pc-04 tlin    | print jobs vanish, no error |
| `wrong-dns`               | pc-02 gokafor | internal sites/file server unreachable |
| `group-removed`           | pc-03 ogrant  | dropped from a security group → share denied |
| `mapped-drive-perms`      | pc-01 asloane | share `valid users` set to the wrong group |
| `expired-service-account` | pc-04 tlin    | `svc-scanner` expired → scheduled job fails |
| `mail-filter-blackhole`   | pc-03 ogrant  | osTicket reject-filter eats her emails |
| `clock-skew`              | pc-04 tlin    | clock +11 min → Kerberos re-auth loop |

```sh
scripts/lab.sh scenarios                  # list them (ACTIVE ones flagged)
scripts/run-scenario.sh locked-account     # inject fault, wait 20-90s, file the ticket
scripts/run-scenario.sh disk-full --now    # skip the delay
scripts/run-scenario.sh wrong-dns --no-ticket   # inject only

scripts/verify.sh locked-account           # PASS/FAIL — checks the ROOT CAUSE
scripts/reset-scenario.sh locked-account    # undo one
scripts/reset-scenario.sh --all             # undo everything + clear demo tickets
```

`verify.sh` is deliberately strict: it checks that the underlying fault is gone,
not that the symptom is masked. Reset the password without clearing the lockout,
patch `/etc/hosts` instead of the resolver, add the user to a *different* group —
all still `FAIL`.

## Dashboard (Phase 3) — http://localhost:3000

One container, `React + Vite + Tailwind` front end + `FastAPI` back end.

- **Endpoint grid** — one card per PC, live-polling its `:9000` agent every 5 s:
  green / amber / red, disk bar, service pills (ssh · cron · print · dns · ldap ·
  krb), status reason, last-check time. A red card's status dot pulses.
- **Ticket queue** — read **straight from the osTicket DB, read-only** (a
  `dashboard` MySQL user with `SELECT` only; osTicket's API only creates tickets).
  Per-ticket SLA countdown ticking every second, amber under 1 h, red +
  `BREACH` badge on breach.
- **Metrics strip** — **tickets you've solved** (session count, from the lab's
  own solved log) · open right now · avg time to fix (ticket filed → verified) ·
  SLA breaches.
- **The loop** — hit **Start a ticket**: a fault breaks a workstation *now*, and
  a few seconds later the user "notices" and the ticket lands in the amber
  **Your open work** panel (complaint, category, affected machine up front).
  The card gives one copy-paste line — `<fix> && scripts/verify.sh <name>` —
  that fixes it *and* prints a full-width green **PASS** / red **FAIL** block in
  the terminal. A PASS also pops a green **"Solved"** modal (whether you ran it
  in the terminal or clicked **Check my fix**) and bumps *Tickets you've solved*.
  **why / full write-up** expands `solution.md`.
- **One at a time** — the next ticket won't arrive until the current one is
  solved (or **Clear it**). Turn on **Auto tickets** (header) to have the next
  one file itself automatically a few seconds after you finish.
- `scripts/verify.sh` with **no argument** checks every active scenario;
  `check` is an alias in the built-in terminal.
- **Built-in terminal** — a collapsible panel (xterm.js ↔ a bash session in the
  dashboard container, which has `docker` + `compose` and the repo at `/lab`).
  Paste the fix, run it. `.env` is sourced so `$MARIADB_ROOT_PASSWORD` etc.
  work. No separate Terminal window needed. *Local-lab convenience — anyone who
  can reach `:3000` gets this shell.*
- **Logins & passwords** — a collapsible panel listing the osTicket / AD / SSH /
  DB credentials (with copy buttons), read live from `.env`.
- **Or pick a specific scenario** — a collapsed list at the bottom for choosing
  which fault to fire.
- **How it works** button — a 4-step explainer with a "give me a ticket"
  shortcut, for anyone opening the dashboard cold.

It drives the scenario engine through the mounted Docker socket and files
scenario tickets via the host's published port, so the API key's source-IP
check still passes.

## Day in the life

1. **Morning:** `scripts/lab.sh health` — all green. Queue empty.
2. **Fire a ticket:** `scripts/run-scenario.sh locked-account`. It breaks PC-01's
   account, waits a beat, then files a ticket the way Aaron would actually write
   it. The cause is **not** in the ticket.
3. **Triage:** read the ticket at http://localhost:8080/scp, check
   `scripts/lab.sh health pc-01`, ssh in, poke AD with `samba-tool`.
4. **Fix the root cause** — `samba-tool user unlock asloane`, not a password reset.
5. **Verify:** `scripts/verify.sh locked-account` → `PASS`.
6. **Check your work** against `scenarios/locked-account.solution.md`.
7. **Reset** when done: `scripts/reset-scenario.sh --all`.

---

## Handy commands

```sh
scripts/lab.sh up             # build + start everything
scripts/lab.sh status         # docker compose ps
scripts/lab.sh health         # endpoint health, one line each
scripts/lab.sh health pc-02   # full JSON for one endpoint
scripts/lab.sh logs samba-dc  # follow a service's logs
scripts/lab.sh sql            # mysql shell into the osticket DB
scripts/lab.sh scenarios      # list fault scenarios
scripts/lab.sh run  <name>    # = scripts/run-scenario.sh
scripts/lab.sh verify <name>  # = scripts/verify.sh
scripts/lab.sh reset --all    # undo all scenarios + clear demo tickets
scripts/lab.sh active         # which scenarios are currently injected
scripts/lab.sh down           # stop (keeps state)
scripts/lab.sh nuke           # stop + wipe AD / DB / tickets (docker compose down -v)
```

---

## Layout

```
helpdesk-lab/
├─ docker-compose.yml          core stack
├─ .env                        all credentials & tunables
├─ samba-ad-dc/                AD DC image: provision + seed 25 users
│  ├─ Dockerfile
│  ├─ entrypoint.sh
│  ├─ seed-ad.sh
│  └─ users.csv                edit to change the roster
├─ endpoint/                   workstation image
│  ├─ Dockerfile
│  ├─ entrypoint.sh
│  └─ agent.py                 the health agent
├─ osticket/
│  └─ seed.sql                 departments / SLA / help topics / API key
├─ scripts/
│  ├─ lab.sh                   convenience wrapper for everything below
│  ├─ run-scenario.sh          inject a fault + file its ticket
│  ├─ verify.sh                PASS/FAIL root-cause check
│  ├─ reset-scenario.sh        undo a scenario / the whole lab
│  ├─ _engine.py               scenario engine (parses the YAML, does the work)
│  ├─ health.py                endpoint health summary
│  └─ seed-osticket.sh         one-shot config seeder
├─ scenarios/
│  ├─ <name>.yaml              fault + ticket + inject/verify/reset commands
│  └─ <name>.solution.md       the answer (never read by the engine)
├─ dashboard/
│  ├─ Dockerfile               node build → python runtime, one image
│  ├─ backend/main.py          FastAPI: /api/endpoints /tickets /metrics /scenarios
│  └─ frontend/                React + Vite + Tailwind
└─ .labstate/                  which scenarios are currently injected (git-ignored)
```

## Notes & gotchas

- **First osTicket boot is slow** (QEMU). `docker compose logs -f osticket` shows
  the installer. Health goes green when it's done.
- **`samba-dc` runs `privileged`.** Samba AD DC wants a broad set of caps;
  privileged is the pragmatic choice for a throwaway lab.
- **Endpoints use `SYS_TIME` + libfaketime** so the clock-skew scenario can shift
  *one endpoint's* Kerberos clock without touching the host. They also run with
  `init: true` so killed services (the print scenario) are reaped, not zombied.
- **`docker compose down` can take 30-60s** — the privileged `samba-dc` is slow
  to stop. Be patient; don't Ctrl-C it.
- **`/scratch` is a 256 MB tmpfs** — that's the "disk" the disk-full scenario
  fills, so cleanup is instant.
- Reset a single endpoint with `docker compose restart pc-0X`. Reset the whole
  lab with `scripts/lab.sh nuke && scripts/lab.sh up`.
